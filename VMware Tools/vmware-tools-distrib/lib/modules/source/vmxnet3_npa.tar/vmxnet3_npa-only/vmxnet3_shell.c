/*********************************************************
 * Copyright (C) 2007-2010 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/

#include "driver-config.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
#error "vmxnet3 driver is not supported on kernels earlier than 2.6"
#endif

#include "vm_device_version.h"

#include "vmxnet3_int.h"
#include "vmxnet3_shm.h"

char vmxnet3_driver_name[] = "vmxnet3";
#define VMXNET3_DRIVER_DESC "VMware vmxnet3 virtual NIC driver"

static const struct pci_device_id vmxnet3_pciid_table[] = {
	{PCI_DEVICE(PCI_VENDOR_ID_VMWARE, PCI_DEVICE_ID_VMWARE_VMXNET3)},
	{0}
};

MODULE_DEVICE_TABLE(pci, vmxnet3_pciid_table);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)
static int disable_lro;
#endif

static atomic_t devices_found;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 2)
static unsigned int num_enable_shm;
#endif
#define VMXNET3_SHM_MAX_DEVICES 10
#define VMXNET3_MAX_DEVICES 16	/* XXX What is the maximum number of vmxnet3
				 * adapters which we support in a VM ?*/

static int enable_shm[VMXNET3_SHM_MAX_DEVICES + 1] =
{ [0 ... VMXNET3_SHM_MAX_DEVICES] = -1 };
static char *shm_disclaimer = NULL;
static int correct_shm_disclaimer;
static int shm_pool_size = SHM_DEFAULT_DATA_SIZE;

static int num_tqs[VMXNET3_MAX_DEVICES + 1] =
{ [0 ... VMXNET3_MAX_DEVICES] = 1 };
static int num_rqs[VMXNET3_MAX_DEVICES + 1] =
{ [0 ... VMXNET3_MAX_DEVICES] = 1 };
static int share_irq[VMXNET3_MAX_DEVICES + 1] =
{ [0 ... VMXNET3_MAX_DEVICES] = 2 };

#define VMXNET3_SHM_DISCLAIMER "IReallyWantThisModeIAmAVMwarePartner"

static void vmxnet3_write_mac_addr(struct vmxnet3_adapter *adapter, u8 *mac);

/*
 * This is the text segment that'll be used to load HW plugins code.
 */
static uint8 vmxnet3_plugin_code_mem[NPA_PLUGIN_NUMPAGES * PAGE_SIZE *
                                     NPA_MAX_PLUGINS_PER_VM]
   __attribute__(( aligned(PAGE_SIZE),section (".npatext") ));

extern uint32 NPA_PluginMain(struct Plugin_Api *pluginApi);

/*
 *    Enable/Disable the given intr
 */

static inline void
vmxnet3_enable_intr(struct vmxnet3_adapter *adapter, unsigned intr_idx)
{
	if (intr_idx == adapter->intr.event_intr_idx)
		VMXNET3_WRITE_BAR0_REG(adapter, VMXNET3_REG_IMR + intr_idx * 8,
				       0);
	else
		Plugin_EnableInterrupt(adapter, intr_idx);
}


static inline void
vmxnet3_disable_intr(struct vmxnet3_adapter *adapter, unsigned intr_idx)
{
	if (intr_idx == adapter->intr.event_intr_idx)
		VMXNET3_WRITE_BAR0_REG(adapter, VMXNET3_REG_IMR + intr_idx * 8,
				       1);
	else
		Plugin_DisableInterrupt(adapter, intr_idx);
}


/*
 *    Enable/Disable all intrs used by the device
 */

static void
vmxnet3_enable_all_intrs(struct vmxnet3_adapter *adapter)
{
	int i;

	for (i = 0; i < adapter->intr.num_intrs; i++)
		vmxnet3_enable_intr(adapter, i);
        adapter->shared->devRead.intrConf.intrCtrl &= ~VMXNET3_IC_DISABLE_ALL;
}


static void
vmxnet3_disable_all_intrs(struct vmxnet3_adapter *adapter)
{
	int i;

        adapter->shared->devRead.intrConf.intrCtrl |= VMXNET3_IC_DISABLE_ALL;
	for (i = 0; i < adapter->intr.num_intrs; i++)
		vmxnet3_disable_intr(adapter, i);
}


static INLINE void
vmxnet3_ack_events(struct vmxnet3_adapter *adapter, u32 events)
{
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_ECR, events);
}


static inline Bool
vmxnet3_tq_stopped(struct vmxnet3_tx_queue *tq, struct vmxnet3_adapter *adapter)
{
	return netif_queue_stopped(adapter->netdev);
}


/*
 *
 * Request the stack to start/stop/wake the tq. This only deals with the OS
 * side, it does NOT handle the device side
 */
static inline void
vmxnet3_tq_start(struct vmxnet3_tx_queue *tq, struct vmxnet3_adapter  *adapter)
{
	tq->stopped = FALSE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
	netif_start_queue(adapter->netdev);
#else
	netif_start_subqueue(adapter->netdev, (tq - adapter->tx_queue));
#endif
}


static inline void
vmxnet3_tq_wake(struct vmxnet3_tx_queue *tq, struct vmxnet3_adapter  *adapter)
{
	tq->stopped = FALSE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
	netif_wake_queue(adapter->netdev);
#else
	netif_wake_subqueue(adapter->netdev, (tq - adapter->tx_queue));
#endif
}


static inline void
vmxnet3_tq_stop(struct vmxnet3_tx_queue *tq, struct vmxnet3_adapter  *adapter)
{
	tq->stopped = TRUE;
	tq->num_stop++;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
	netif_stop_queue(adapter->netdev);
#else
	netif_stop_subqueue(adapter->netdev, (tq - adapter->tx_queue));
#endif
}


/*
 * This may start or stop the tx queue.
 */

static void
vmxnet3_check_link(struct vmxnet3_adapter *adapter, Bool affectTxQueue)
{
	u32 ret;
	int i;

	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD, VMXNET3_CMD_GET_LINK);
	ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
	adapter->link_speed = ret >> 16;
	if (ret & 1) { /* Link is up. */
		printk(KERN_INFO "%s: NIC Link is Up %d Mbps\n",
		       adapter->netdev->name, adapter->link_speed);
		if (!netif_carrier_ok(adapter->netdev))
			netif_carrier_on(adapter->netdev);

		if (affectTxQueue) {
			for (i = 0; i < adapter->num_tx_queues; i++) {
				vmxnet3_tq_start(&adapter->tx_queue[i],
						 adapter);
			}
		}
	} else {
		printk(KERN_INFO "%s: NIC Link is Down\n",
		       adapter->netdev->name);
		if (netif_carrier_ok(adapter->netdev))
			netif_carrier_off(adapter->netdev);

		if (affectTxQueue) {
			for (i = 0; i < adapter->num_tx_queues; i++) {
				vmxnet3_tq_stop(&adapter->tx_queue[i], adapter);
			}
		}
	}
}


/*
 * process events indicated in ECR
 */

static void
vmxnet3_process_events(struct vmxnet3_adapter *adapter)
{
	u32 events = le32_to_cpu(adapter->shared->ecr);
        u32 ret;
	int i;

	if (!events)
		return;

	vmxnet3_ack_events(adapter, events);

	/* Check if link state has changed */
	if (events & VMXNET3_ECR_LINK)
		vmxnet3_check_link(adapter, TRUE);

	/* Check if there is an error on xmit/recv queues */
	if (events & (VMXNET3_ECR_TQERR | VMXNET3_ECR_RQERR)) {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_GET_QUEUE_STATUS);

		for (i = 0; i < adapter->num_tx_queues; i++) {
			if (adapter->tqd_start[i].status.stopped) {
				printk(KERN_ERR "%s: tq[%d] error 0x%x\n",
				       adapter->netdev->name, i,
			       le32_to_cpu(adapter->tqd_start[i].status.error));
			}
		}
		for (i = 0; i < adapter->num_rx_queues; i++) {
			if (adapter->rqd_start[i].status.stopped) {
				printk(KERN_ERR "%s: rq[%d] error 0x%x\n",
				       adapter->netdev->name, i,
				       adapter->rqd_start[i].status.error);
			}
		}

		compat_schedule_work(&adapter->reset_work);
	}
	/* Check if passthru is requested */
	if (events & VMXNET3_ECR_DIC) {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_GET_DID_LO);
		ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);

		if (ret == PCI_DEVICE_ID_VMWARE_VMXNET3) {
			printk(KERN_ERR "%s: DIC: passthru -> emulation\n", adapter->netdev->name);
			compat_schedule_work(&adapter->reset_work);
		} else if (ret == VMXNET3_DID_PASSTHRU) {
			printk(KERN_ERR "%s: DIC: emulation -> passthru\n", adapter->netdev->name);
			compat_schedule_work(&adapter->passthru_work);
		} else {
			BUG_ON(0);
		}
	}
}


static void
vmxnet3_unmap_tx_buf(struct vmxnet3_tx_buf_info *tbi,
		     struct pci_dev *pdev)
{
	if (tbi->map_type == VMXNET3_MAP_SINGLE)
		pci_unmap_single(pdev, tbi->dma_addr, tbi->len,
				 PCI_DMA_TODEVICE);
	else if (tbi->map_type == VMXNET3_MAP_PAGE)
		pci_unmap_page(pdev, tbi->dma_addr, tbi->len,
			       PCI_DMA_TODEVICE);
	else
		BUG_ON(tbi->map_type != VMXNET3_MAP_NONE);

	tbi->map_type = VMXNET3_MAP_NONE; /* to help debugging */
}


/*
 *    Returns # of tx descs that this pkt used
 *
 * Side-effects:
 *    1. mappings and skb are freed
 *    2. buf_info[] are updated
 *    3. tx_shadow_ring.next2comp is updated.
 */

static int
vmxnet3_unmap_pkt(struct vmxnet3_tx_queue *tq, struct pci_dev *pdev,
		  struct vmxnet3_adapter *adapter)
{
	struct vmxnet3_tx_shadow_ring *ring = &tq->shadow_ring;
	struct sk_buff *skb;
	uint32 eop_idx;
	int entries = 0;

	eop_idx = ring->base[ring->next2comp].eop_idx;
	dev_dbg(&adapter->pdev->dev, "tx complete [%u %u]\n",
		ring->next2comp, eop_idx);
	skb = ring->base[ring->next2comp].skb;
	BUG_ON(skb == NULL);
	ring->base[ring->next2comp].skb = NULL;

	while (ring->next2comp != eop_idx) {
		vmxnet3_unmap_tx_buf(ring->base + ring->next2comp, pdev);

		/* update next2comp w/o tx_lock. Since we are marking more,
		 * instead of less, tx ring entries avail, the worst case is
		 * that the tx routine incorrectly re-queues a pkt due to
		 * insufficient tx ring entries.
		 */
		vmxnet3_tx_shadow_ring_adv_next2comp(ring);
		entries++;
	}

	vmxnet3_dev_kfree_skb_any(adapter, skb);
	return entries;
}


static void
vmxnet3_tq_cleanup(struct vmxnet3_tx_queue *tq,
		   struct vmxnet3_adapter *adapter)
{
	struct vmxnet3_tx_shadow_ring *ring = &tq->shadow_ring;

	while (ring->next2comp != ring->next2fill) {
		struct vmxnet3_tx_buf_info *tbi;

		tbi = ring->base + ring->next2comp;

		vmxnet3_unmap_tx_buf(tbi, adapter->pdev);
		if (tbi->skb) {
			vmxnet3_dev_kfree_skb_any(adapter, tbi->skb);
			tbi->skb = NULL;
		}
		vmxnet3_tx_shadow_ring_adv_next2comp(ring);
	}

	/* sanity check */
#ifdef VMX86_DEBUG
	{
		/* verify all buffers are indeed unmapped and freed */
		int i;
		for (i = 0; i < ring->size; i++) {
			BUG_ON(ring->base[i].skb != NULL ||
			       ring->base[i].map_type != VMXNET3_MAP_NONE);
		}
	}
#endif

	ring->next2fill = ring->next2comp = 0;
}


static void
vmxnet3_tq_cleanup_all(struct vmxnet3_adapter *adapter)
{
	int i;

	for (i = 0; i < adapter->num_tx_queues; i++) {
		vmxnet3_tq_cleanup(&adapter->tx_queue[i], adapter);
	}
}


/*
 *	free rings and buf_info for the tx queue. There must be no pending pkt
 *	in the tx ring. the .base fields of all rings and buf_info will be
 *	set to NULL
 */

static void
vmxnet3_tq_destroy(struct vmxnet3_tx_queue *tq,
		   struct vmxnet3_adapter *adapter)
{
	if (tq->plugin_tq->ringBaseVA) {
		pci_free_consistent(adapter->pdev, tq->plugin_tq->ringLength,
				    tq->plugin_tq->ringBaseVA,
				    tq->plugin_tq->ringBasePA);
		tq->plugin_tq->ringBaseVA = NULL;
		tq->plugin_tq->ringBasePA = 0;
	}
	if (tq->data_ring.base) {
		pci_free_consistent(adapter->pdev, tq->data_ring.size *
				    sizeof(struct Vmxnet3_TxDataDesc),
				    tq->data_ring.base, tq->data_ring.basePA);
		tq->data_ring.base = NULL;
	}
	if (tq->shadow_ring.base) {
		vfree(tq->shadow_ring.base);
		tq->shadow_ring.base = NULL;
	}
	if (tq->sg_list.elements) {
		kfree(tq->sg_list.elements);
		tq->sg_list.elements = NULL;
	}
}


/* Destroy all tx queues */
void
vmxnet3_tq_destroy_all(struct vmxnet3_adapter *adapter)
{
	int i;

	for (i = 0; i < adapter->num_tx_queues; i++) {
		vmxnet3_tq_destroy(&adapter->tx_queue[i], adapter);
	}
}


/*
 *    reset all internal states and rings for a tx queue
 * Side-effects:
 *    1. contents of the rings are reset to 0
 *    2. bookkeeping data is reset
 */
static void
vmxnet3_tq_init(struct vmxnet3_tx_queue *tq,
		struct vmxnet3_adapter *adapter)
{
	int i;

	/* reset the data ring contents to 0 and reset the data ring states */
	tq->data_ring.next2fill = 0;
	tq->data_ring.next2comp = 0;
	memset(tq->data_ring.base, 0,
	       tq->data_ring.size * sizeof(struct Vmxnet3_TxDataDesc));

	/* reset the bookkeeping data */
	tq->shadow_ring.next2fill = 0;
	tq->shadow_ring.next2comp = 0;
	memset(tq->shadow_ring.base, 0, tq->shadow_ring.size *
	       sizeof(struct vmxnet3_tx_shadow_ring));
	for (i = 0; i < tq->shadow_ring.size; i++) {
		tq->shadow_ring.base[i].map_type = VMXNET3_MAP_NONE;
	}

	/* stats are not reset */
}


/* Init all tx queues */
static void
vmxnet3_tq_init_all(struct vmxnet3_adapter *adapter)
{
	int i;

	for (i = 0; i < adapter->num_tx_queues; i++) {
		vmxnet3_tq_init(&adapter->tx_queue[i], adapter);
	}
}


/*
 * allocate and initialize rings for the tx queue, also allocate and
 * initialize buf_info. Returns 0 on success, negative errno on failure.
 */
static int
vmxnet3_tq_create(struct vmxnet3_tx_queue *tq,
		  struct vmxnet3_adapter *adapter)
{
	uint32 ring_length;

	BUG_ON(tq->plugin_tq->ringSize == 0 ||
	       tq->data_ring.size != tq->plugin_tq->ringSize);
	BUG_ON((tq->plugin_tq->ringSize & VMXNET3_RING_SIZE_MASK) != 0);
	BUG_ON(tq->plugin_tq->ringBaseVA || tq->data_ring.base ||
	       tq->shadow_ring.base || tq->sg_list.elements);

	/*
	 * We don't know the underlying hardware's descriptor size,
	 * thus use the maximum allowed descriptor size.
	 */
	ring_length = tq->plugin_tq->ringSize *
		PLUGIN_SHARED_AREA_TX_MAX_DESC_SIZE_BYTES;
	/* Add room for potential alignment */
	ring_length += PLUGIN_SHARED_AREA_TX_ALLOCATION_ALIGN - 1;
	/*
	 * Again, we don't know the underlying hardware's mode of
	 * operation, so let's give room for multiple rings.
	 */
	tq->plugin_tq->ringLength = PLUGIN_SHARED_AREA_TX_ALLOCATION_MULTIPLE *
		ring_length + PLUGIN_SHARED_AREA_TX_EXTRA_ALLOCATION;
	tq->plugin_tq->ringBaseVA = pci_alloc_consistent(adapter->pdev,
				      tq->plugin_tq->ringLength,
				      (dma_addr_t *)&tq->plugin_tq->ringBasePA);
	if (!tq->plugin_tq->ringBaseVA) {
		printk(KERN_ERR "%s: failed to allocate tx ring\n",
		       adapter->netdev->name);
		goto err;
	}

	tq->data_ring.base = pci_alloc_consistent(adapter->pdev,
			     tq->data_ring.size *
			     sizeof(struct Vmxnet3_TxDataDesc),
			     &tq->data_ring.basePA);
	if (!tq->data_ring.base) {
		printk(KERN_ERR "%s: failed to allocate data ring\n",
		       adapter->netdev->name);
		goto err;
	}

	tq->shadow_ring.size =
		VMXNET3_TX_SHADOW_RING_SIZE(tq->plugin_tq->ringSize);
	tq->shadow_ring.base = vmalloc(tq->shadow_ring.size *
				       sizeof(struct vmxnet3_tx_buf_info));
	if (!tq->shadow_ring.base) {
		printk(KERN_ERR "%s: failed to allocate tx shadow ring\n",
		       adapter->netdev->name);
		goto err;
	}

	tq->sg_list.elements = kcalloc(VMXNET3_SGLIST_MAX,
				       sizeof(struct Plugin_SgElement),
				       GFP_KERNEL);
	if (!tq->sg_list.elements) {
		printk(KERN_ERR "%s: failed to allocate tx sglist\n",
		       adapter->netdev->name);
		goto err;
	}

	return 0;

err:
	vmxnet3_tq_destroy(tq, adapter);
	return -ENOMEM;
}


/*
 * It assumes the skb still has space to accommodate the frag. It only
 * increments skb->data_len
 */

static void
vmxnet3_append_frag(struct sk_buff *skb, Shell_RecvFrameSG *sg,
		    struct vmxnet3_rx_buf_info *rbi)
{
	struct skb_frag_struct *frag = skb_shinfo(skb)->frags +
		skb_shinfo(skb)->nr_frags;

	BUG_ON(skb_shinfo(skb)->nr_frags >= MAX_SKB_FRAGS);

	frag->page = rbi->page;
	frag->page_offset = 0;
	frag->size = sg->length;
	skb->data_len += frag->size;
	skb_shinfo(skb)->nr_frags++;
}

/*
 *
 * Free any pages which were attached to the frags of the
 * spare skb.  this can happen when the spare skb is attached
 * to the rx ring to prevent starvation, but there was no
 * issue with page allocation.
 *
 */

static void
vmxnet3_rx_spare_skb_free_frags(struct vmxnet3_adapter *adapter,
				struct sk_buff *skb)
{
        int i;
        for (i = 0; i < skb_shinfo(skb)->nr_frags; i++) {
                struct skb_frag_struct *frag = &skb_shinfo(skb)->frags[i];
                BUG_ON(frag->page != 0);
                vmxnet3_put_page(adapter, frag->page);
                frag->page = 0;
                frag->size = 0;
        }
        skb_shinfo(skb)->nr_frags = 0;
        skb->data_len = 0;
}


/*
 * Map the tx buffer and set up ONLY TXD.{addr, len, gen} based on the mapping.
 * It sets the other fields of the descriptors to 0.
 * Side Effects :
 *    1. the corresponding buf_info entries are upated,
 *    2. ring indices are advanced
 */

static void
vmxnet3_map_pkt(struct sk_buff *skb, uint32 copy_size,
		struct vmxnet3_tx_queue *tq, struct vmxnet3_adapter *adapter)
{
	struct vmxnet3_tx_buf_info *tbi = NULL;
	struct vmxnet3_tx_buf_info *sop_tbi = NULL;
	Plugin_SgList *sg_list = &tq->sg_list;
	uint32 idx = 0;
	int i;

	BUG_ON(copy_size > vmxnet3_skb_headlen(adapter, skb));

	sop_tbi = tq->shadow_ring.base + tq->shadow_ring.next2fill;

	/* no need to map the buffer if headers are copied */
	if (copy_size) {
		tbi = tq->shadow_ring.base + tq->shadow_ring.next2fill;
		tbi->skb = NULL;
		tbi->map_type = VMXNET3_MAP_NONE;
		tbi->len = 0;
		tbi->dma_addr = 0;

		sg_list->elements[idx].pa = tq->data_ring.basePA +
			tq->data_ring.next2fill * sizeof(Vmxnet3_TxDataDesc);
		sg_list->elements[idx].length = copy_size;
		sg_list->firstSgVA =
                   tq->data_ring.base[tq->data_ring.next2fill].data;
		idx++;

		dev_dbg(&adapter->pdev->dev, "txd[%u]: 0x%"FMT64"x 0x%x\n",
			tq->shadow_ring.next2fill, sg_list->elements[idx].pa,
			sg_list->elements[idx].length);

		vmxnet3_tx_shadow_ring_adv_next2fill(&tq->shadow_ring);
	}

	/*
	 * linear part can use multiple tx desc in the plugin if it's
	 * big, but only one in the shadow/data ring
	 */
	if (vmxnet3_skb_headlen(adapter, skb) > copy_size) {
		tbi = tq->shadow_ring.base + tq->shadow_ring.next2fill;
		tbi->skb = NULL;
		tbi->map_type = VMXNET3_MAP_SINGLE;
		tbi->len = vmxnet3_skb_headlen(adapter, skb) - copy_size;
		tbi->dma_addr = vmxnet3_map_single(adapter, skb, copy_size,
				tbi->len, PCI_DMA_TODEVICE);

		sg_list->elements[idx].pa = tbi->dma_addr;
		sg_list->elements[idx].length = tbi->len;
                if (idx == 0) {
                   /*
                    * sometimes header are too big to fit in the data ring,
                    * so we have to use skb->data. we know headers are
                    * accessible since we may have done a skb_pull if needed.
                    * NOTE: this is only for HW plugins, no need to
                    * support for shm devices.
                    */
                   if (!adapter->is_shm) {
                      sg_list->firstSgVA = skb->data;	
                   }
                }
		idx++;

		dev_dbg(&adapter->pdev->dev,
			"txd[%u]: 0x%"FMT64"x 0x%x\n",
			tq->shadow_ring.next2fill, (uint64)tbi->dma_addr, tbi->len);

		vmxnet3_tx_shadow_ring_adv_next2fill(&tq->shadow_ring);
	}

	for (i = 0; i < skb_shinfo(skb)->nr_frags; i++) {
		struct skb_frag_struct *frag = &skb_shinfo(skb)->frags[i];

		tbi = tq->shadow_ring.base + tq->shadow_ring.next2fill;
		tbi->skb = NULL;
		tbi->map_type = VMXNET3_MAP_PAGE;
		tbi->len = frag->size;
		tbi->dma_addr = vmxnet3_map_page(adapter, frag->page,
						frag->page_offset, frag->size,
						PCI_DMA_TODEVICE);

		sg_list->elements[idx].pa = tbi->dma_addr;
		sg_list->elements[idx].length = tbi->len;
		idx++;

		dev_dbg(&adapter->pdev->dev,
			"txd[%u]: 0x%"FMT64"x 0x%x\n",
			tq->shadow_ring.next2fill, (uint64)tbi->dma_addr, tbi->len);

		vmxnet3_tx_shadow_ring_adv_next2fill(&tq->shadow_ring);
	}

	/* set the last buf_info for the pkt */
	sop_tbi->skb = skb;
	sop_tbi->eop_idx = tq->shadow_ring.next2fill;

	BUG_ON(idx >= VMXNET3_SGLIST_MAX);
	sg_list->numElements = idx;
	sg_list->totalLength = vmxnet3_skb_len(adapter, skb);
}


/*
 *    parse and copy relevant protocol headers:
 *     For a tso pkt, relevant headers are L2/3/4 including options
 *     For a pkt requesting csum offloading, they are L2/3 and may include L4
 *     if it's a TCP/UDP pkt
 *
 *    The implementation works only when h/w vlan insertion is used, see PR
 *    171928
 *
 * Result:
 *    -1:  error happens during parsing
 *     0:  protocol headers parsed, but too big to be copied
 *     n:  protocol headers parsed and copied; n is # of bytes copied
 *
 * Side-effects:
 *    1. related *info fields are updated.
 *    2. the portion copied is guaranteed to be in the linear part
 *
 */
static int
vmxnet3_parse_and_copy_hdr(struct sk_buff *skb, struct vmxnet3_tx_queue *tq,
			   Plugin_SendInfo *info,
			   struct vmxnet3_adapter *adapter)
{
	struct Vmxnet3_TxDataDesc *tdd;
	unsigned int copy_size;

	if (info->tsoMss) {
		info->tcp = TRUE;
		info->tso = TRUE;
		info->xsumTcpOrUdp = TRUE;

		info->ipHeaderOffset = compat_skb_network_offset(skb);
		info->l4HeaderOffset = compat_skb_transport_offset(skb);
		info->l4DataOffset = info->l4HeaderOffset +
			compat_skb_tcp_header(skb)->doff * 4;

		copy_size = info->l4DataOffset;
	} else {
		unsigned int pull_size;

		info->tcp = FALSE;
		info->udp = FALSE;
		info->tso = FALSE;
		if (info->ipv4) {
			if (compat_skb_ip_header(skb)->protocol == IPPROTO_TCP)
				info->tcp = TRUE;
			else if (compat_skb_ip_header(skb)->protocol ==
				                                   IPPROTO_UDP)
				info->udp = TRUE;
		}
		else if (info->ipv6) {
			/* XXX what about option headers */
			if (compat_skb_ipv6_header(skb)->nexthdr ==
			                                           IPPROTO_TCP)
				info->tcp = TRUE;
			else if (compat_skb_ipv6_header(skb)->nexthdr ==
				                                   IPPROTO_UDP)
				info->udp = TRUE;
		}

		if (skb->ip_summed == VM_TX_CHECKSUM_PARTIAL) {
			info->ipHeaderOffset = compat_skb_network_offset(skb);
			info->l4HeaderOffset = compat_skb_transport_offset(skb);

			if (info->ipv4 || info->ipv6) {
				if (info->tcp) {
					info->xsumTcpOrUdp = TRUE;
					pull_size = info->l4HeaderOffset +
						    sizeof(struct tcphdr);

					if (unlikely(!compat_pskb_may_pull(skb,
								pull_size))) {
						goto err;
					}
					info->l4DataOffset =
						info->l4HeaderOffset +
					  compat_skb_tcp_header(skb)->doff * 4;
					copy_size = info->l4DataOffset;
				} else if (info->udp) {
					info->xsumTcpOrUdp = TRUE;
					info->l4DataOffset =
						info->l4HeaderOffset +
						sizeof(struct udphdr);
					copy_size = info->l4DataOffset;
				} else {
					info->xsumTcpOrUdp = FALSE;
					copy_size = info->l4HeaderOffset;
				}
			} else {
				info->xsumTcpOrUdp = FALSE;
				/* for simplicity, don't copy L4 headers */
				copy_size = info->l4HeaderOffset;
			}
		} else {
			info->xsumTcpOrUdp = FALSE;
			/* copy as much as allowed */
			copy_size = min((unsigned int)VMXNET3_HDR_COPY_SIZE,
					vmxnet3_skb_headlen(adapter, skb));
		}

		if (!adapter->is_shm) {
		         /* make sure headers are accessible directly */
			if (unlikely(!compat_pskb_may_pull(skb, copy_size)))
				goto err;

		}
	}

#ifdef VMX86_DEBUG
	BUG_ON((info->tcp || info->udp) && !(info->ipv4 || info->ipv6));
	BUG_ON(info->xsumTcpOrUdp && !(info->tcp || info->udp));
	BUG_ON(info->tso && !(info->tcp || info->tsoMss));

	BUG_ON(info->xsumTcpOrUdp && !info->ipHeaderOffset);
	BUG_ON(info->xsumTcpOrUdp && !(info->l4HeaderOffset ||
				       info->l4DataOffset));
#endif

	if (unlikely(copy_size > VMXNET3_HDR_COPY_SIZE)) {
		tq->stats.oversized_hdr++;
		return 0;
	}

	tdd = tq->data_ring.base + tq->data_ring.next2fill;
	BUG_ON(copy_size > vmxnet3_skb_headlen(adapter, skb));

	if (!adapter->is_shm) {
		memcpy(tdd->data, skb->data, copy_size);
	} else {
		void *virt = kmap(VMXNET3_SHM_IDX2PAGE(adapter->shm,
				  VMXNET3_SHM_SKB_GETIDX(skb)));
		memcpy(tdd->data, virt, copy_size);
		kunmap(VMXNET3_SHM_IDX2PAGE(adapter->shm,
		       VMXNET3_SHM_SKB_GETIDX(skb)));
	}

	dev_dbg(&adapter->pdev->dev, "copy %u bytes to dataRing[%u]\n",
		copy_size, tq->data_ring.next2fill);
	return copy_size;

err:
	return -1;
}


/*
 *    Fix pkt headers for tso. ip hdr and tcp hdr are changed
 */

static void
vmxnet3_prepare_tso(struct sk_buff *skb, Plugin_SendInfo *info)
{
	struct tcphdr *tcph = compat_skb_tcp_header(skb);
	if (info->ipv4) {
		struct iphdr *iph = compat_skb_ip_header(skb);
		iph->check = 0;
		tcph->check = ~csum_tcpudp_magic(iph->saddr, iph->daddr, 0,
						 IPPROTO_TCP, 0);
#ifdef NETIF_F_TSO6
	} else {
		struct ipv6hdr *iph = (struct ipv6hdr *)
				      compat_skb_network_header(skb);
		tcph->check = ~csum_ipv6_magic(&iph->saddr, &iph->daddr, 0,
					       IPPROTO_TCP, 0);
#endif
	}
}

inline void vmxnet3_le32_add_cpu(uint32 *addTo, uint32 addThis)
{
	*addTo = cpu_to_le32(le32_to_cpu(*addTo) + addThis);
}


/*
 *    transmit a pkt thru a given tq
 *
 * Result:
 *    COMPAT_NETDEV_TX_OK:      descriptors are setup successfully
 *    COMPAT_NETDEV_TX_OK:      error occured, the pkt is dropped
 *    COMPAT_NETDEV_TX_BUSY:    tx ring is full, queue is stopped
 *
 * Side-effects:
 *    1. tx ring may be changed
 *    2. tq stats may be updated accordingly
 *    3. shared->txNumDeferred may be updated
 */

int
vmxnet3_tq_xmit(struct sk_buff *skb,
		struct vmxnet3_tx_queue *tq,
		struct vmxnet3_adapter *adapter,
		struct net_device *netdev)
{
	int copy_size;
	u32 count;
	unsigned long flags;
	uint32 shadow_idx;
	Bool lastPktHint;
	int i;

	/* conservatively estimate # of descriptors to use */
	count = VMXNET3_TXD_NEEDED(vmxnet3_skb_headlen(adapter, skb)) +
		skb_shinfo(skb)->nr_frags + 1;

	tq->info.ipv4 = (skb->protocol == __constant_ntohs(ETH_P_IP));
	tq->info.ipv6 = (skb->protocol == __constant_ntohs(ETH_P_IPV6));
	tq->info.tsoMss = compat_skb_mss(skb);
	if (tq->info.tsoMss) {
		if (compat_skb_header_cloned(skb)) {
			if (unlikely(pskb_expand_head(skb, 0, 0,
						      GFP_ATOMIC) != 0)) {
				tq->stats.drop_tso++;
				goto drop_pkt;
			}
			tq->stats.copy_skb_header++;
		}
		vmxnet3_prepare_tso(skb, &tq->info);
	} else {
		if (unlikely(count > VMXNET3_MAX_TXD_PER_PKT)) {
			if (unlikely(adapter->is_shm)) {
				BUG_ON(count > VMXNET3_MAX_TXD_PER_PKT_SHM);
				if (count > VMXNET3_MAX_TXD_PER_PKT_SHM) {
					tq->stats.drop_too_many_frags++;
					goto drop_pkt;
				}
			} else {
				/* non-tso pkts must not use more than
				 * VMXNET3_MAX_TXD_PER_PKT entries
				 */
				if (compat_skb_linearize(skb) != 0) {
					tq->stats.drop_too_many_frags++;
					goto drop_pkt;
				}
				tq->stats.linearized++;

				/* recalculate the # of descriptors to use */
				count = VMXNET3_TXD_NEEDED(vmxnet3_skb_headlen(
							adapter, skb)) + 1;
			}
		}
	}

	copy_size = vmxnet3_parse_and_copy_hdr(skb, tq, &tq->info, adapter);
	if (copy_size >= 0) {
		/* hdrs parsed, check against other limits */
		if (tq->info.tsoMss) {
			if (unlikely(tq->info.l4DataOffset >
				     VMXNET3_MAX_TX_BUF_SIZE)) {
				goto hdr_too_big;
			}
		} else {
			if (skb->ip_summed == VM_TX_CHECKSUM_PARTIAL) {
				if (unlikely(tq->info.l4HeaderOffset +
					     compat_skb_csum_offset(skb) >
					     VMXNET3_MAX_CSUM_OFFSET)) {
					goto hdr_too_big;
				}
			}
		}
	} else {
		tq->stats.drop_hdr_inspect_err++;
		goto drop_pkt;
	}

	spin_lock_irqsave(&tq->tx_lock, flags);

	if (vmxnet3_tx_data_ring_desc_avail(&tq->data_ring) < 1) {
		tq->stats.tx_ring_full++;
		dev_dbg(&adapter->pdev->dev, "tx queue stopped on %s, data ring"
			" next2comp %u next2fill %u\n", adapter->netdev->name,
			tq->data_ring.next2comp, tq->data_ring.next2fill);

		vmxnet3_tq_stop(tq, adapter);
		spin_unlock_irqrestore(&tq->tx_lock, flags);
		return COMPAT_NETDEV_TX_BUSY;
	}

	/*
	 * XXX: PR 531329, we should stop the queue based on plugin
	 * ring and not shadow ring
	 */
	if (count > vmxnet3_tx_shadow_ring_desc_avail(&tq->shadow_ring)) {
		tq->stats.tx_ring_full++;
		dev_dbg(&adapter->pdev->dev, "tx queue stopped on %s, shadow "
			" ring next2comp %u next2fill %u\n",
			adapter->netdev->name,
			tq->shadow_ring.next2comp, tq->shadow_ring.next2fill);

		vmxnet3_tq_stop(tq, adapter);
		spin_unlock_irqrestore(&tq->tx_lock, flags);
		return COMPAT_NETDEV_TX_BUSY;
	}

	/* fill shadow ring and populate sg_list with addr & len */
	shadow_idx = tq->shadow_ring.next2fill;
	vmxnet3_map_pkt(skb, copy_size, tq, adapter);

	if (tq->info.tsoMss) {
		vmxnet3_le32_add_cpu(&tq->shared->txNumDeferred,
				(vmxnet3_skb_len(adapter, skb) - copy_size +
				 tq->info.tsoMss - 1) / tq->info.tsoMss);
	} else {
		vmxnet3_le32_add_cpu(&tq->shared->txNumDeferred, 1);
	}

	if (!adapter->passthru) {
		if (le32_to_cpu(tq->shared->txNumDeferred) >=
		    le32_to_cpu(tq->shared->txThreshold)) {
			tq->shared->txNumDeferred = 0;
			lastPktHint = TRUE;
		} else {
			lastPktHint = FALSE;
		}
	} else {
		lastPktHint = TRUE;
	}

	if (vlan_tx_tag_present(skb)) {
		tq->info.vlan = TRUE;
		tq->info.vlanTag = vlan_tx_tag_get(skb);
	}

	if (Plugin_AddFrameToTxRing(adapter, tq->qid, &tq->info, &tq->sg_list,
				    lastPktHint) != 0) {
		tq->stats.tx_ring_full++;
		dev_dbg(&adapter->pdev->dev, "tx queue stopped on %s, plugin "
			"ring: full\n", adapter->netdev->name);

		/* roll back shadow ring and unmap pkt */
		for (i = shadow_idx; i < tq->shadow_ring.next2fill; i++) {
			vmxnet3_unmap_tx_buf(tq->shadow_ring.base + i,
					     adapter->pdev);
			tq->shadow_ring.base[i].skb = NULL;
		}
		tq->shadow_ring.next2fill = shadow_idx;
		tq->sg_list.numElements = 0;
		tq->sg_list.totalLength = 0;

		vmxnet3_tq_stop(tq, adapter);
		spin_unlock_irqrestore(&tq->tx_lock, flags);
		return COMPAT_NETDEV_TX_BUSY;
	}

	vmxnet3_tx_data_ring_adv_next2fill(&tq->data_ring);

	spin_unlock_irqrestore(&tq->tx_lock, flags);

	netdev->trans_start = jiffies;

	return COMPAT_NETDEV_TX_OK;

hdr_too_big:
	tq->stats.drop_oversized_hdr++;
drop_pkt:
	tq->stats.drop_total++;
	vmxnet3_dev_kfree_skb(adapter, skb);
	return COMPAT_NETDEV_TX_OK;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
static int
#else
static netdev_tx_t
#endif
vmxnet3_xmit_frame(struct sk_buff *skb, struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);

	if (adapter->is_shm) {
		return vmxnet3_shm_start_tx(skb, netdev);
	} else {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 25) || defined(CONFIG_NETDEVICES_MULTIQUEUE)
		BUG_ON(skb->queue_mapping > adapter->num_tx_queues);
		return vmxnet3_tq_xmit(skb,
				       &adapter->tx_queue[skb->queue_mapping],
				       adapter, netdev);
#else
		return vmxnet3_tq_xmit(skb, &adapter->tx_queue[0], adapter,
				       netdev);
#endif
	}
}

static void SHELL_ABI vmxnet3_shell_free_buffer(struct Shell_RxQueueHandle *,
                                                uint32);

/*
 * Unmap and free the rx buffers allocated to the rx queue. Other resources
 * are NOT freed. This is the counterpart of vmxnet3_rq_init()
 * Side-effects:
 *    1. indices and gen of each ring are reset to the initial value
 *    2. buf_info[] and buf_info2[] are cleared.
 */

static void
vmxnet3_rq_cleanup(struct vmxnet3_rx_queue *rq,
		   struct vmxnet3_adapter *adapter)
{
	struct vmxnet3_rx_buf_info *rbi;
	u32 i;

	for (i = 0; i < rq->plugin_rq->ringSize *
                PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE;
             i++) {
		rbi = rq->buf_info + i;
		if (rbi->buf_type != VMXNET3_RX_BUF_NONE)
			vmxnet3_shell_free_buffer(
					   (struct Shell_RxQueueHandle*)rq, i);
	}

	BUG_ON(rq->avail_skbs != 0);

        /* free starvation prevention skb if allocated */
        if (rq->spare_skb) {
                vmxnet3_rx_spare_skb_free_frags(adapter, rq->spare_skb);
                compat_dev_kfree_skb(rq->spare_skb, FREE_WRITE);
                rq->spare_skb = NULL;
        }
}


static void
vmxnet3_rq_cleanup_all(struct vmxnet3_adapter *adapter)
{
	int i;
	
	for (i = 0; i < adapter->num_rx_queues; i++) {
		vmxnet3_rq_cleanup(&adapter->rx_queue[i], adapter);
	}
}


/*
 *    Free rings and buf_info for the rx queue. The rx buffers must have
 *    ALREADY been freed. the .base fields of all rings will be set to NULL
 */

static void
vmxnet3_rq_destroy(struct vmxnet3_rx_queue *rq,
		struct vmxnet3_adapter *adapter)
{
#ifdef VMX86_DEBUG
	/* all rx buffers must have already been freed */
	int i;

	if (rq->buf_info) {
		for (i = 0;
		     i < rq->plugin_rq->ringSize *
                        PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE;
		     i++) {
			BUG_ON(rq->buf_info[i].buf_type != VMXNET3_RX_BUF_NONE);
			BUG_ON(rq->buf_info[i].skb != NULL);
			BUG_ON(rq->buf_info[i].page != NULL);
		}
	}
#endif

	if (rq->plugin_rq->ringBaseVA) {
		pci_free_consistent(adapter->pdev, rq->plugin_rq->ringLength,
				    rq->plugin_rq->ringBaseVA,
				    rq->plugin_rq->ringBasePA);
		rq->plugin_rq->ringBaseVA = NULL;
		rq->plugin_rq->ringBasePA = 0;
	}

	if (rq->buf_info) {
		vfree(rq->buf_info);
		rq->buf_info = NULL;
	}
}


void
vmxnet3_rq_destroy_all(struct vmxnet3_adapter *adapter)
{
	int i;

	for (i = 0; i < adapter->num_rx_queues; i++) {
		vmxnet3_rq_destroy(&adapter->rx_queue[i], adapter);
	}
}


/*
 *    initialize buf_info, allocate rx buffers and fill the rx rings. On
 *    failure, the rx buffers already allocated are NOT freed
 */

static int
vmxnet3_rq_init(struct vmxnet3_rx_queue *rq,
		struct vmxnet3_adapter  *adapter)
{
	struct vmxnet3_rx_buf_info *rbi;
	int i;

	BUG_ON(adapter->rx_buf_per_pkt <= 0 ||
	       rq->plugin_rq->ringSize % adapter->rx_buf_per_pkt != 0);

	/* initialize buf_info */
	for (i = 0; i < rq->plugin_rq->ringSize *
                PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE;
             i++) {
		rbi = rq->buf_info + i;
		rbi->buf_type = VMXNET3_RX_BUF_NONE;
		rbi->skb = NULL;
		rbi->page = NULL;
	}

        /* allocate ring starvation protection */
        rq->spare_skb = dev_alloc_skb(PAGE_SIZE);
        if (rq->spare_skb == NULL) {
                vmxnet3_rq_cleanup(rq, adapter);
		return -ENOMEM;
        }

	rq->avail_skbs = 0;

	/* stats are not reset */
	return 0;
}


static int
vmxnet3_rq_init_all(struct vmxnet3_adapter *adapter)
{
	int i, err = 0;

	for (i = 0; i < adapter->num_rx_queues; i++) {
		err = vmxnet3_rq_init(&adapter->rx_queue[i], adapter);
		if (UNLIKELY(err)) {
			printk(KERN_ERR "%s: failed to initialize rx queue%i\n",
			       adapter->netdev->name, i);
			break;
		}
	}
	return err;

}


/*
 *    allocate and initialize two cmd rings and the completion ring for the
 *    given rx queue. Also allocate and initialize buf_info.
 *    rx buffers are NOT allocated
 */
static int
vmxnet3_rq_create(struct vmxnet3_rx_queue *rq, struct vmxnet3_adapter *adapter)
{
	uint32 ring_length;

	BUG_ON(rq->plugin_rq->ringSize == 0);
	BUG_ON((rq->plugin_rq->ringSize & VMXNET3_RING_SIZE_MASK) != 0);
	BUG_ON(rq->plugin_rq->ringBaseVA || rq->buf_info);
	BUG_ON(rq->plugin_rq->ringSize % adapter->rx_buf_per_pkt != 0);

	/*
	 * We don't know the underlying hardware's descriptor size,
	 * thus use the maximum allowed descriptor size.
	 */
	ring_length = rq->plugin_rq->ringSize *
		PLUGIN_SHARED_AREA_RX_MAX_DESC_SIZE_BYTES;
	/* Add room for potential alignment */
	ring_length += PLUGIN_SHARED_AREA_RX_ALLOCATION_ALIGN - 1;
	/*
	 * Again, we don't know the underlying hardware's mode of
	 * operation, so let's give room for multiple rings.
	 */
	rq->plugin_rq->ringLength = PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE *
		ring_length + PLUGIN_SHARED_AREA_RX_EXTRA_ALLOCATION;
	rq->plugin_rq->ringBaseVA = pci_alloc_consistent(adapter->pdev,
				       rq->plugin_rq->ringLength,
				       (dma_addr_t*)&rq->plugin_rq->ringBasePA);
        rq->plugin_rq->miscInfo = NULL;
	if (!rq->plugin_rq->ringBaseVA) {
		printk(KERN_ERR "%s: failed to allocate rx ring\n",
		       adapter->netdev->name);
		goto err;
	}

	rq->buf_info = vmalloc(rq->plugin_rq->ringSize *
                               PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE *
			       sizeof(struct vmxnet3_rx_buf_info));
	if (!rq->buf_info) {
		printk(KERN_ERR "%s: failed to allocate rx bufinfo\n",
		       adapter->netdev->name);
		goto err;
	}

	return 0;

err:
	vmxnet3_rq_destroy(rq, adapter);
	return -ENOMEM;
}


static int
vmxnet3_rq_create_all(struct vmxnet3_adapter *adapter)
{
	int i, err = 0;

	for (i = 0; i < adapter->num_rx_queues; i++) {
		err = vmxnet3_rq_create(&adapter->rx_queue[i], adapter);
		if (UNLIKELY(err)) {
			printk(KERN_ERR "%s: failed to create rx queue%i\n",
			       adapter->netdev->name, i);
			goto err_out;
		}
	}
	return err;
err_out:
	vmxnet3_rq_destroy_all(adapter);
	return err;
}

/*
 *   Find the interrupt index corresponding to the tx/rx queue
 */

enum vmxnet3_qtype {
	VMXNET3_QTYPE_RX = 1,
	VMXNET3_QTYPE_TX,
	VMXNET3_QTYPE_OTHER
};

static int
vmxnet3_find_intr_idx(struct vmxnet3_intr *intr,
		enum vmxnet3_qtype qtype, int qnum)
{
	int i;

	for (i = 0; i < intr->num_intrs; i++) {
		if (qtype == VMXNET3_QTYPE_RX &&
		    (intr->ctx[i].rx_map & (1 << qnum))) {
			return i;
		} else if (qtype == VMXNET3_QTYPE_TX &&
			   (intr->ctx[i].tx_map & (1 << qnum))) {
			return i;
		} else if (intr->ctx[i].other) {
			return i;
		}
	}

	BUG_ON(TRUE);
	return 0;
}



/* Multiple queue aware polling function for tx and rx */
static int
vmxnet3_do_poll(struct vmxnet3_adapter *adapter, int budget)
{
	uint32 add_rxb;
	int rcd_total = 0;
	int i;

	if (unlikely(adapter->shared->ecr))
		vmxnet3_process_events(adapter);

	for (i = 0; i < adapter->num_tx_queues; i++)
		Plugin_CheckTxRing(adapter, i);

	for (i = 0; i < adapter->num_rx_queues && budget > 0; i++) {
		adapter->rx_queue[i].rxd_done = 0;
		add_rxb = Plugin_CheckRxRing(adapter, i, budget);
		if (add_rxb) {
			Plugin_AddBuffersToRxRing(adapter, i);
		}
		budget -= adapter->rx_queue[i].rxd_done;
		rcd_total += adapter->rx_queue[i].rxd_done;
	}
	return rcd_total;
}


#ifdef VMXNET3_NAPI
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 24)

/*
 * New NAPI polling function. Returns # of the NAPI credit consumed (# of rx
 * descriptors processed)
 */
static int
vmxnet3_poll(struct napi_struct *napi, int budget)
{
	struct vmxnet3_rx_queue *rx_queue = container_of(napi,
					  struct vmxnet3_rx_queue, napi);
	int rxd_done;

	rxd_done = vmxnet3_do_poll(rx_queue->adapter, budget);

	if (rxd_done < budget) {
		compat_napi_complete(rx_queue->adapter->netdev, napi);
		vmxnet3_enable_all_intrs(rx_queue->adapter);
	}
	return rxd_done;
}

/*
 * new NAPI polling function for MSI-X mode with multiple Rx queues
 * Returns the # of the NAPI credit consumed (# of rx descriptors processed)
 */
static int
vmxnet3_poll_rx_only(struct napi_struct *napi, int budget)
{
	struct vmxnet3_rx_queue *rq = container_of(napi,
						struct vmxnet3_rx_queue, napi);
	struct vmxnet3_adapter *adapter = rq->adapter;
	uint32 add_rxb;

        rq->rxd_done = 0;
	add_rxb = Plugin_CheckRxRing(adapter, rq - adapter->rx_queue, budget);
	if (add_rxb) {
		Plugin_AddBuffersToRxRing(adapter, rq - adapter->rx_queue);
	}

	if (rq->rxd_done < budget) {
		compat_napi_complete(adapter->netdev, napi);
		vmxnet3_enable_intr(adapter, rq->intr_idx);
	}
	return rq->rxd_done;
}

#else
/* old NAPI */
/*
 * Result:
 *    0: napi is done
 *    1: continue polling
 */

static int
vmxnet3_poll(struct net_device *poll_dev, int *budget)
{
	int rxd_done, quota;
	struct vmxnet3_adapter *adapter = netdev_priv(poll_dev);

	quota = min(*budget, poll_dev->quota);

	rxd_done = vmxnet3_do_poll(adapter, quota);

	*budget -= rxd_done;
	poll_dev->quota -= rxd_done;

	if (rxd_done < quota) {
		compat_napi_complete(poll_dev, &adapter->rx_queue[0].napi);
		vmxnet3_enable_all_intrs(adapter);
		return 0;
	}

	return 1; /* not done */
}

/*
 * use one shared napi instead.
 * Returns 0 when napi is done  and 1 when it should continue polling
 */

static int
vmxnet3_poll_rx_only(struct net_device *poll_dev, int *budget)
{
	uint32 add_rxb;
	int quota;
	struct vmxnet3_adapter *adapter = netdev_priv(poll_dev);
	quota = min(*budget, poll_dev->quota);

        adapter->rx_queue[0].rxd_done = 0;
	add_rxb = Plugin_CheckRxRing(adapter, 0, *budget);
	if (add_rxb) {
		Plugin_AddBuffersToRxRing(adapter, 0);
	}

	*budget -= adapter->rx_queue[0].rxd_done;
	poll_dev->quota -= adapter->rx_queue[0].rxd_done;

	if (adapter->rx_queue[0].rxd_done < quota) {
		compat_napi_complete(poll_dev, &adapter->rx_queue[0].napi);
		/* enable all rx interrupts*/
		vmxnet3_enable_intr(adapter,
				    adapter->rx_queue[0].intr_idx);
		return 0;
	}

	return 1; /* not done */
}

#endif /* VMXNET3_NEW_NAPI  */
#endif /* VMXNET3_NAPI  */


/* Interrupt handler for vmxnet3  */
static compat_irqreturn_t
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
vmxnet3_intr(int irq, void *ctxptr, struct pt_regs * regs)
#else
vmxnet3_intr(int irq, void *ctxptr)
#endif
{
	struct vmxnet3_intr_ctx *ctx = (struct vmxnet3_intr_ctx *)ctxptr;
	struct vmxnet3_adapter *adapter = ctx->adapter;
	struct vmxnet3_rx_queue *rq = adapter->rx_queue;
	int i;
#ifndef VMXNET3_NAPI
	uint32 add_rxb;
#endif

	if (adapter->intr.type == VMXNET3_IT_INTX) {
		u32 icr = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_ICR);
		if (unlikely(icr == 0))
			/* not ours */
			return IRQ_NONE;
	}

	/* disable intr if needed */
	if (adapter->intr.mask_mode == VMXNET3_IMM_ACTIVE)
		vmxnet3_disable_intr(adapter, ctx->index);

	if (adapter->intr.type == VMXNET3_IT_INTX ||
	    adapter->intr.type == VMXNET3_IT_MSI ||
	    adapter->intr.num_intrs == 1) {
		/* Poll everything */
#ifdef VMXNET3_NAPI
		compat_napi_schedule(adapter->netdev, &rq->napi);
#else
		vmxnet3_do_poll(adapter, rq->size);
		vmxnet3_enable_intr(adapter, ctx->index);
#endif
		return COMPAT_IRQ_HANDLED;
	}

	/* handle MSI-x interrupt */
	if (ctx->tx_map) {
		u32 mask = 1;
		for (i = 0; i < adapter->num_tx_queues; i++) {
			if (ctx->tx_map & mask)
				Plugin_CheckTxRing(adapter, i);
			mask <<= 1;
		}
	}

	if (ctx->rx_map) {
		u32 mask = 1;
		for (i = 0; i < adapter->num_rx_queues; i++) {
			if (!(mask & ctx->rx_map)) {
				mask >>= 1;
				continue;
			}
			rq = &adapter->rx_queue[i];
#ifdef VMXNET3_NAPI
			compat_napi_schedule(adapter->netdev, &rq->napi);
#else
			add_rxb = Plugin_CheckRxRing(adapter, i, rq->size);
			if (add_rxb) {
				Plugin_AddBuffersToRxRing(adapter, i);
			}
#endif
		}
	}

	if (ctx->other == TRUE && unlikely(adapter->shared->ecr))
		vmxnet3_process_events(adapter);

#ifdef VMXNET3_NAPI
	if (!ctx->rx_map)
#endif
		vmxnet3_enable_intr(adapter, ctx->index);
	return COMPAT_IRQ_HANDLED;
}

#ifdef CONFIG_NET_POLL_CONTROLLER
static void
vmxnet3_netpoll(struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);

	if (adapter->intr.mask_mode == VMXNET3_IMM_ACTIVE)
		vmxnet3_disable_all_intrs(adapter);

	vmxnet3_do_poll(adapter, adapter->rx_queue[0].plugin_rq->ringSize);
	vmxnet3_enable_all_intrs(adapter);
}
#endif		/* CONFIG_NET_POLL_CONTROLLER */


/*
 * event_intr_idx and intr_idx for different comp rings get updated here.
 */

static int
vmxnet3_request_irqs(struct vmxnet3_adapter *adapter)
{
	int err = 0;
	struct vmxnet3_intr_ctx *ctx = adapter->intr.ctx;

#ifdef CONFIG_PCI_MSI
	if (adapter->intr.type == VMXNET3_IT_MSIX) {
		int i;
		/* we only use 1 MSI-X vector */
		for(i = 0; i < adapter->intr.num_intrs; i++) {
			ctx = &adapter->intr.ctx[i];
			sprintf(ctx->name, "%s:v%d", adapter->netdev->name, i);
			err = request_irq(adapter->intr.msix_entries[i].vector,
					  vmxnet3_intr, 0, adapter->netdev->name
					  , ctx);
			if (err) {
				printk(KERN_ERR "Failed to request irq for MSIX"
				       ", %s, error : %d \n", ctx->name, err);
				return err;
			}
		}
	} else if (adapter->intr.type == VMXNET3_IT_MSI) {
		err = request_irq(adapter->pdev->irq, vmxnet3_intr, 0,
				  adapter->netdev->name, ctx);
	} else {
#endif
		err = request_irq(adapter->pdev->irq, vmxnet3_intr,
				  COMPAT_IRQF_SHARED, adapter->netdev->name,
				  ctx);

#ifdef CONFIG_PCI_MSI
	}
#endif
	if (err)
		printk(KERN_ERR "Failed to request irq %s (intr type:%d), error"
		       ":%d\n", adapter->netdev->name, adapter->intr.type, err);


	if (!err) {
		int i;
		/* init our intr settings */
		for (i = 0; i < adapter->intr.num_intrs; i++)
			adapter->intr.ctx[i].modlevel = UPT1_IML_ADAPTIVE;

		/* next setup intr index for all intr sources */
                for (i = 0; i < adapter->num_tx_queues; i++)
			adapter->tx_queue[i].intr_idx = vmxnet3_find_intr_idx(
					&adapter->intr, VMXNET3_QTYPE_TX, i);

                for (i = 0; i < adapter->num_rx_queues; i++)
			adapter->rx_queue[i].intr_idx =  vmxnet3_find_intr_idx(
					&adapter->intr, VMXNET3_QTYPE_RX, i);

		adapter->intr.event_intr_idx = vmxnet3_find_intr_idx(
					&adapter->intr, VMXNET3_QTYPE_OTHER, i);

		printk(KERN_INFO "%s: intr type %u, mode %u, %u vectors "
		       "allocated\n", adapter->netdev->name, adapter->intr.type,
		       adapter->intr.mask_mode, adapter->intr.num_intrs);
	}

	return err;
}


static void
vmxnet3_free_irqs(struct vmxnet3_adapter *adapter)
{
	BUG_ON(adapter->intr.type == VMXNET3_IT_AUTO ||
	       adapter->intr.num_intrs <= 0);

	switch (adapter->intr.type) {
#ifdef CONFIG_PCI_MSI
	case VMXNET3_IT_MSIX:
	{
		int i;

		for (i = 0; i < adapter->intr.num_intrs; i++)
			free_irq(adapter->intr.msix_entries[i].vector,
				 &adapter->intr.ctx[i]);
		break;
	}
	case VMXNET3_IT_MSI:
		free_irq(adapter->pdev->irq, adapter->intr.ctx);
		break;
#endif
	case VMXNET3_IT_INTX:
		free_irq(adapter->pdev->irq, adapter->intr.ctx);
		break;
	default:
		BUG_ON(TRUE);
	}
}


static void
vmxnet3_vlan_rx_register(struct net_device *netdev, struct vlan_group *grp)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	struct Vmxnet3_DriverShared *shared = adapter->shared;
	u32 *vfTable = adapter->shared->devRead.rxFilterConf.vfTable;

	if (grp) {
                /*
                 * VLAN striping feature already enabled by default, no need to
                 * enable it here.
                 */
		if (adapter->netdev->features & NETIF_F_HW_VLAN_RX) {
			int i;
			adapter->vlan_grp = grp;

			/*
			 *  Clear entire vfTable; then enable untagged pkts.
			 *  Note: setting one entry in vfTable to non-zero turns
			 *  on VLAN rx filtering.
			 */
			for (i = 0; i < VMXNET3_VFT_SIZE; i++)
				vfTable[i] = 0;

			VMXNET3_SET_VFTABLE_ENTRY(vfTable, 0);
			VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
					       VMXNET3_CMD_UPDATE_VLAN_FILTERS);
		} else {
			printk(KERN_ERR "%s: vlan_rx_register when device has "
			       "no NETIF_F_HW_VLAN_RX\n", netdev->name);
		}
	} else {
		struct Vmxnet3_DSDevRead *devRead = &shared->devRead;
		adapter->vlan_grp = NULL;

		if (le64_to_cpu(devRead->misc.uptFeatures) & UPT1_F_RXVLAN) {
			int i;

			for (i = 0; i < VMXNET3_VFT_SIZE; i++) {
				/* clear entire vfTable; this also disables
				 * VLAN rx filtering
				 */
				vfTable[i] = 0;
			}
			VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
					       VMXNET3_CMD_UPDATE_VLAN_FILTERS);
		}
	}
}


static void
vmxnet3_restore_vlan(struct vmxnet3_adapter *adapter)
{
	if (adapter->vlan_grp) {
		u16 vid;
		u32 *vfTable = adapter->shared->devRead.rxFilterConf.vfTable;
		Bool activeVlan = FALSE;

		for (vid = 0; vid < VLAN_GROUP_ARRAY_LEN; vid++) {
			if (compat_vlan_group_get_device(adapter->vlan_grp,
							 vid)) {
				VMXNET3_SET_VFTABLE_ENTRY(vfTable, vid);
				activeVlan = TRUE;
			}
		}
		if (activeVlan) {
			/* continue to allow untagged pkts */
			VMXNET3_SET_VFTABLE_ENTRY(vfTable, 0);
		}
	}
}

/* Inherit net_device features from real device to VLAN device. */
void
vmxnet3_vlan_features(struct vmxnet3_adapter *adapter, u16 vid, Bool allvids)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
	struct net_device *v_netdev;

	if (adapter->vlan_grp) {
		if (allvids) {
			for (vid = 0; vid < VLAN_GROUP_ARRAY_LEN; vid++) {
				v_netdev = compat_vlan_group_get_device(
							adapter->vlan_grp, vid);
				if (v_netdev) {
					v_netdev->features |=
						      adapter->netdev->features;
					compat_vlan_group_set_device(
					      adapter->vlan_grp, vid, v_netdev);
				}
			}
		} else {
			v_netdev = compat_vlan_group_get_device(
							adapter->vlan_grp, vid);
			if (v_netdev) {
				v_netdev->features |= adapter->netdev->features;
				compat_vlan_group_set_device(adapter->vlan_grp,
							     vid, v_netdev);
			}
		}
	}
#endif
}


static void
vmxnet3_vlan_rx_add_vid(struct net_device *netdev, u16 vid)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	u32 *vfTable = adapter->shared->devRead.rxFilterConf.vfTable;

	vmxnet3_vlan_features(adapter, vid, FALSE);
	VMXNET3_SET_VFTABLE_ENTRY(vfTable, vid);
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_UPDATE_VLAN_FILTERS);
}


static void
vmxnet3_vlan_rx_kill_vid(struct net_device *netdev, u16 vid)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	u32 *vfTable = adapter->shared->devRead.rxFilterConf.vfTable;

	VMXNET3_CLEAR_VFTABLE_ENTRY(vfTable, vid);
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_UPDATE_VLAN_FILTERS);
}


/*
 * Allocate a buffer and copy into the mcast list. Returns NULL if the mcast
 * list exceeds the limit. Returns the addr of the allocated buffer or NULL.
 */

static u8 *
vmxnet3_copy_mc(struct net_device *netdev)
{
	u8 *buf = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
	u32 sz = netdev_mc_count(netdev) * ETH_ALEN;
#else
	u32 sz = netdev->mc_count * ETH_ALEN;
#endif

	/* Vmxnet3_RxFilterConf.mfTableLen is u16. */
	if (sz <= 0xffff) {
		/* We may be called with BH disabled */
		buf = kmalloc(sz, GFP_ATOMIC);
		if (buf) {
			int i = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
			struct netdev_hw_addr *ha;
			netdev_for_each_mc_addr(ha, netdev)
				memcpy(buf + i++ * ETH_ALEN, ha->addr,
				       ETH_ALEN);
#else
			struct dev_mc_list *mc = netdev->mc_list;
			for (i = 0; i < netdev->mc_count; i++) {
				BUG_ON(!mc);
				memcpy(buf + i * ETH_ALEN, mc->dmi_addr,
				       ETH_ALEN);
				mc = mc->next;
			}
#endif
		}
	}
	return buf;
}


static void
vmxnet3_set_mc(struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	struct Vmxnet3_RxFilterConf *rxConf =
					&adapter->shared->devRead.rxFilterConf;
	u8 *new_table = NULL;
	u32 new_mode = VMXNET3_RXM_UCAST;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
	u32 mc_count = netdev_mc_count(netdev);
#else
	u32 mc_count = netdev->mc_count;
#endif

	if (netdev->flags & IFF_PROMISC)
		new_mode |= VMXNET3_RXM_PROMISC;

	if (netdev->flags & IFF_BROADCAST)
		new_mode |= VMXNET3_RXM_BCAST;

	if (netdev->flags & IFF_ALLMULTI)
		new_mode |= VMXNET3_RXM_ALL_MULTI;
	else if (mc_count > 0) {
		new_table = vmxnet3_copy_mc(netdev);
		if (new_table) {
			new_mode |= VMXNET3_RXM_MCAST;
			rxConf->mfTableLen = cpu_to_le16(mc_count *
							 ETH_ALEN);
			rxConf->mfTablePA = cpu_to_le64(virt_to_phys(
					    new_table));
		} else {
			printk(KERN_INFO "%s: failed to copy mcast list, "
			       "setting ALL_MULTI\n", netdev->name);
			new_mode |= VMXNET3_RXM_ALL_MULTI;
		}
	}


	if (!(new_mode & VMXNET3_RXM_MCAST)) {
		rxConf->mfTableLen = 0;
		rxConf->mfTablePA = 0;
	}

	if (new_mode != rxConf->rxMode) {
		rxConf->rxMode = cpu_to_le32(new_mode);
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_UPDATE_RX_MODE);
	}

	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_UPDATE_MAC_FILTERS);

	kfree(new_table);
}


/*
 * Wipes out the whole driver_shared area and re-initializes it
 */

static void
vmxnet3_setup_driver_shared(struct vmxnet3_adapter *adapter)
{
	struct Vmxnet3_DriverShared *shared = adapter->shared;
	struct Vmxnet3_DSDevRead *devRead = &shared->devRead;
	struct Vmxnet3_TxQueueConf *tqc;
	struct Vmxnet3_RxQueueConf *rqc;
	uint32 ring1_size;
	uint64 pa;
	int i;

	memset(shared, 0, sizeof(*shared));

	/* driver settings */
	shared->magic = cpu_to_le32(VMXNET3_REV1_MAGIC);
	devRead->misc.driverInfo.version = cpu_to_le32(
						VMXNET3_DRIVER_VERSION_NUM);
	devRead->misc.driverInfo.gos.gosBits = (sizeof(void *) == 4 ?
				VMXNET3_GOS_BITS_32 : VMXNET3_GOS_BITS_64);
	devRead->misc.driverInfo.gos.gosType = VMXNET3_GOS_TYPE_LINUX;
	*((u32 *)&devRead->misc.driverInfo.gos) = cpu_to_le32(
				*((u32 *)&devRead->misc.driverInfo.gos));
	devRead->misc.driverInfo.vmxnet3RevSpt = cpu_to_le32(1);
	devRead->misc.driverInfo.uptVerSpt = cpu_to_le32(1);

	devRead->misc.ddPA = cpu_to_le64(virt_to_phys(adapter));
	devRead->misc.ddLen = cpu_to_le32(sizeof(struct vmxnet3_adapter));

	/* set up feature flags */
	if (adapter->rxcsum)
		set_flag_le64(&devRead->misc.uptFeatures, UPT1_F_RXCSUM);

	if (adapter->lro) {
		set_flag_le64(&devRead->misc.uptFeatures, UPT1_F_LRO);
		devRead->misc.maxNumRxSG = cpu_to_le16(1 + MAX_SKB_FRAGS);
	}
	if (adapter->netdev->features & NETIF_F_HW_VLAN_RX) {
                 /*
                  * Even there is no tag to be stripped,
                  * VLAN Tag stripping is enabled by default. This is
                  * required to work around  a Palo bug.
                  */
		set_flag_le64(&devRead->misc.uptFeatures, UPT1_F_RXVLAN);
	}

	devRead->misc.mtu = cpu_to_le32(adapter->netdev->mtu);
	devRead->misc.queueDescPA = cpu_to_le64(adapter->queue_desc_pa);
	devRead->misc.queueDescLen = cpu_to_le32(
		adapter->num_tx_queues * sizeof(struct Vmxnet3_TxQueueDesc) +
		adapter->num_rx_queues * sizeof(struct Vmxnet3_RxQueueDesc));

	/* tx queue settings */
	devRead->misc.numTxQueues = adapter->num_tx_queues;
	for(i = 0; i < adapter->num_tx_queues; i++) {
		struct vmxnet3_tx_queue	*tq = &adapter->tx_queue[i];

		BUG_ON(tq->plugin_tq->ringBaseVA == NULL);
		tqc = &adapter->tqd_start[i].conf;		
		pa = tq->plugin_tq->ringBasePA;
		tqc->txRingBasePA   =
			cpu_to_le64(ALIGN(pa, VMXNET3_RING_BA_ALIGN));
		tqc->dataRingBasePA = cpu_to_le64(tq->data_ring.basePA);
		pa += tq->plugin_tq->ringSize * sizeof(Vmxnet3_TxDesc);
		tqc->compRingBasePA =
			cpu_to_le64(ALIGN(pa, VMXNET3_RING_BA_ALIGN));
		tqc->ddPA           =
			cpu_to_le64(virt_to_phys(tq->shadow_ring.base));
		tqc->txRingSize     = cpu_to_le32(tq->plugin_tq->ringSize);
		tqc->dataRingSize   = cpu_to_le32(tq->data_ring.size);
		tqc->compRingSize   = cpu_to_le32(tq->plugin_tq->ringSize);
		tqc->ddLen          =
			cpu_to_le32(sizeof(struct vmxnet3_tx_buf_info) *
				    tq->shadow_ring.size);
		tqc->intrIdx        = tq->intr_idx;

 		dev_dbg(&adapter->pdev->dev, "%s: tqc[%d]: %"FMT64"d %"FMT64"d %"FMT64"d %d\n",
 			adapter->netdev->name, i,
 			tqc->txRingBasePA, tqc->compRingBasePA,
 			tqc->dataRingBasePA, tqc->intrIdx);
	}

	/* rx queue settings */
	if (adapter->lro ||
	    adapter->netdev->mtu > SHELL_SMALL_RECV_BUFFER_SIZE) {
		ring1_size = adapter->rx_queue[0].plugin_rq->ringSize;
	} else {
		/* same as in plugin and windows shell */
		ring1_size = 32;
	}

	devRead->misc.numRxQueues = adapter->num_rx_queues;
	for(i = 0; i < adapter->num_rx_queues; i++) {
 		struct vmxnet3_rx_queue	*rq = &adapter->rx_queue[i];

 		BUG_ON(rq->plugin_rq->ringBaseVA == NULL);
 		rqc = &adapter->rqd_start[i].conf;
		pa = rq->plugin_rq->ringBasePA;
		rqc->rxRingBasePA[0] =
			cpu_to_le64(ALIGN(pa, VMXNET3_RING_BA_ALIGN));
		pa += rq->plugin_rq->ringSize * sizeof(Vmxnet3_RxDesc);
		rqc->rxRingBasePA[1] =
			cpu_to_le64(ALIGN(pa, VMXNET3_RING_BA_ALIGN));
		pa += ring1_size * sizeof(Vmxnet3_RxDesc);
		rqc->compRingBasePA  =
			cpu_to_le64(ALIGN(pa, VMXNET3_RING_BA_ALIGN));
		rqc->ddPA            =
			cpu_to_le64(virt_to_phys(rq->buf_info));
		rqc->rxRingSize[0]   = cpu_to_le32(rq->plugin_rq->ringSize);
		rqc->rxRingSize[1]   = cpu_to_le32(ring1_size);
		rqc->compRingSize    =
			cpu_to_le32(rq->plugin_rq->ringSize + ring1_size);
		rqc->ddLen           =
			cpu_to_le32(sizeof(struct vmxnet3_rx_buf_info) *
				    (rq->plugin_rq->ringSize + ring1_size));
		rqc->intrIdx         = rq->intr_idx;

 		dev_dbg(&adapter->pdev->dev, "%s: rqc[%d]: %"FMT64"d %"FMT64"d %"FMT64"d %d\n",
 			adapter->netdev->name, i,
 			rqc->rxRingBasePA[0], rqc->rxRingBasePA[1],
 			rqc->compRingBasePA, rqc->intrIdx);
	}

	/* intr settings */
	devRead->intrConf.autoMask = adapter->intr.mask_mode ==
				     VMXNET3_IMM_AUTO;
	devRead->intrConf.numIntrs = adapter->intr.num_intrs;
	for (i = 0; i < adapter->intr.num_intrs; i++)
		devRead->intrConf.modLevels[i] = adapter->intr.ctx[i].modlevel;

	devRead->intrConf.eventIntrIdx = adapter->intr.event_intr_idx;
        devRead->intrConf.intrCtrl |= VMXNET3_IC_DISABLE_ALL;

	/* rx filter settings */
	devRead->rxFilterConf.rxMode = 0;
	vmxnet3_restore_vlan(adapter);
        vmxnet3_write_mac_addr(adapter, adapter->netdev->dev_addr);
	/* the rest are already zeroed */
}

/*
 * This function asks the VMX to load the HW plugin inside the guest.
 *
 * First we look for an available region to load the code, then we
 * populate the NPA_PluginConf before issuing the CMD_LOAD_PLUGIN.
 * After this, we set the MMIO address, copy the init opaque data and
 * retrieve the entry poinf of the plugin.
 */

static NPA_PluginMainFunc
vmxnet3_load_plugin(struct vmxnet3_adapter *adapter)
{
	NPA_PluginConf *plugin_conf = adapter->plugin_conf; 
	uint8 *plugin_code_region;
	int ret;
	int i;

	plugin_code_region = vmxnet3_plugin_code_mem;

	/* construct the plugin_conf */
	memset(plugin_conf, 0, sizeof (*plugin_conf));
	BUG_ON(((uintptr_t)plugin_code_region & ~PAGE_MASK));
	plugin_conf->pluginPages.vaddr = (uintptr_t)plugin_code_region;
	plugin_conf->pluginPages.numPages = NPA_PLUGIN_NUMPAGES *
           NPA_MAX_PLUGINS_PER_VM;
	for (i = 0; i < NPA_PLUGIN_NUMPAGES * NPA_MAX_PLUGINS_PER_VM; i++) {
		plugin_conf->pluginPages.pages[i] =
			page_to_pfn(vmalloc_to_page(plugin_code_region +
						    i * PAGE_SIZE));
	}

	plugin_conf->memioPages.startPPN = ALIGN(adapter->plugin_memio_pa,
						 PAGE_SIZE) / PAGE_SIZE;
	plugin_conf->memioPages.numPages = NPA_MEMIO_NUMPAGES;
	plugin_conf->sharedPages.startPPN = ALIGN(adapter->plugin_shared_pa,
						  PAGE_SIZE) / PAGE_SIZE;
	plugin_conf->sharedPages.numPages = NPA_SHARED_NUMPAGES;

	adapter->shared->devRead.pluginConfDesc.confVer = 1;
	adapter->shared->devRead.pluginConfDesc.confLen = sizeof (*plugin_conf);
	adapter->shared->devRead.pluginConfDesc.confPA  =
		virt_to_phys(plugin_conf);

	dev_dbg(&adapter->pdev->dev, "%s: pluginConf: %d 0x%"FMT64"x 0x%"FMT64
                "x 0x%"FMT64"x\n",
		adapter->netdev->name,
		adapter->shared->devRead.pluginConfDesc.confLen,
		adapter->shared->devRead.pluginConfDesc.confPA,
		plugin_conf->pluginPages.vaddr,
		plugin_conf->pluginPages.pages[0]);

	/* issue command to load the plugin */
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_LOAD_PLUGIN);
	ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
	if (ret == VMXNET3_NPA_CMD_SUCCESS) {
		adapter->plugin.memioAddr =
			(void*)ALIGN((uintptr_t)adapter->plugin_memio,
				     PAGE_SIZE);
		memcpy(adapter->plugin.deviceInfo, plugin_conf->deviceInfo,
		       sizeof (adapter->plugin.deviceInfo));
		return (NPA_PluginMainFunc)(uintptr_t)plugin_conf->entryVA;
	}
	return NULL;
}

/*
 * put the vNIC into an operational state. After this function finishes, the
 * adapter is fully functional. It does the following:
 * 1. initialize tq and rq
 * 2. setup intr
 * 3. setup driver_shared
 * 4. initialize the sw or hw plugin
 * 5. fill rx rings with rx buffers
 * 6. activate the dev
 * 7. signal the stack that the vNIC is ready to tx/rx
 * 8. enable intrs for the vNIC
 *
 * load_plugin request loading hardware plugin instead of the default
 * software plugin. It is used when switching to passthrough.
 *
 * Returns:
 *    0 if the vNIC is in operation state
 *    error code if any intermediate step fails.
 */

int
vmxnet3_activate_dev(struct vmxnet3_adapter *adapter, Bool load_plugin)
{
	int err;
	u32 ret;
	int i;

	dev_dbg(&adapter->pdev->dev, "%s: skb_buf_size %d, rx_buf_per_pkt %d, "
		"ring sizes %u %u %u\n", adapter->netdev->name,
		adapter->skb_buf_size, adapter->rx_buf_per_pkt,
		adapter->tx_queue[0].plugin_tq->ringSize,
		adapter->tx_queue[0].shadow_ring.size,
		adapter->rx_queue[0].plugin_rq->ringSize);

	vmxnet3_tq_init_all(adapter);
	err = vmxnet3_rq_init_all(adapter);
	if (err) {
		printk(KERN_ERR "Failed to init rx queue for %s: error %d\n",
		       adapter->netdev->name, err);
		goto rq_err;
	}

	err = vmxnet3_request_irqs(adapter);
	if (err) {
		printk(KERN_ERR "Failed to setup irq for %s: error %d\n",
		       adapter->netdev->name, err);
		goto irq_err;
	}

	vmxnet3_setup_driver_shared(adapter);

	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_DSAL,VMXNET3_GET_ADDR_LO(
			       adapter->shared_pa));
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_DSAH, VMXNET3_GET_ADDR_HI(
			       adapter->shared_pa));

	if (!load_plugin) {
		NPA_PluginMain(&adapter->plugin_api);
		adapter->plugin.memioAddr = adapter->hw_addr0;
		memset(adapter->plugin.deviceInfo, 0,
		       sizeof(adapter->plugin.deviceInfo));
		adapter->plugin.shared = NULL;
		adapter->plugin.sharedLen = 0;
		printk(KERN_ERR "Using s/w api for %s\n",
		       adapter->netdev->name);
	} else {
		NPA_PluginMainFunc plugin_main;
		plugin_main = vmxnet3_load_plugin(adapter);
		/* plugin memioAddr and deviceInfo are set in load_plugin */
		adapter->plugin.shared =
			(void *)ALIGN((uintptr_t)adapter->plugin_shared,
				      PAGE_SIZE);
		adapter->plugin.sharedLen = NPA_SHARED_NUMPAGES * PAGE_SIZE;
		if (plugin_main == NULL) {
			printk(KERN_ERR "Failed to load plugin for %s\n",
			       adapter->netdev->name);
			err = -EINVAL;
			goto activate_err;
		}
		printk(KERN_ERR "Using h/w api %p for %s\n", plugin_main, 
		       adapter->netdev->name);
		plugin_main(&adapter->plugin_api);
	}

	dev_dbg(&adapter->pdev->dev,
		"%s: Plugin API:\n"
		"swInit: %p\n"
		"reinitTxRing: %p\n"
		"reinitRxRing: %p\n"
		"enableInterrupt: %p\n"
		"disableInterrupt: %p\n"
		"addFrameToTxRing: %p\n"
		"checkTxRing: %p\n"
		"checkRxRing: %p\n"
		"addBuffersToRxRing: %p\n",
		adapter->netdev->name,
		adapter->plugin_api.swInit,
		adapter->plugin_api.reinitTxRing,
		adapter->plugin_api.reinitRxRing,
		adapter->plugin_api.enableInterrupt,
		adapter->plugin_api.disableInterrupt,
		adapter->plugin_api.addFrameToTxRing,
		adapter->plugin_api.checkTxRing,
		adapter->plugin_api.checkRxRing,
		adapter->plugin_api.addBuffersToRxRing);

	BUG_ON(!adapter->plugin_api.swInit);
	BUG_ON(!adapter->plugin_api.reinitTxRing);
	BUG_ON(!adapter->plugin_api.reinitRxRing);
	BUG_ON(!adapter->plugin_api.enableInterrupt);
	BUG_ON(!adapter->plugin_api.disableInterrupt);
	BUG_ON(!adapter->plugin_api.addFrameToTxRing);
	BUG_ON(!adapter->plugin_api.checkTxRing);
	BUG_ON(!adapter->plugin_api.checkRxRing);
	BUG_ON(!adapter->plugin_api.addBuffersToRxRing);

	Plugin_SwInit(adapter);

	for (i = 0; i < adapter->num_tx_queues; i++)
		Plugin_ReinitTxRing(adapter, i);
	for (i = 0; i < adapter->num_rx_queues; i++)
		Plugin_ReinitRxRing(adapter, i);

	if (!load_plugin) {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_ACTIVATE_DEV);
		ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
		if (ret != 0) {
			printk(KERN_ERR "Failed to activate dev %s: error %u\n",
			       adapter->netdev->name, ret);
			err = -EINVAL;
			goto activate_err;
		}
	} else {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_ACTIVATE_VF);
		ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
		if (ret != VMXNET3_NPA_CMD_SUCCESS) {
			printk(KERN_ERR "Failed to activate vf %s: error %u\n",
			       adapter->netdev->name, ret);
			err = -EINVAL;
			goto activate_err;
		}
	}
	adapter->passthru = load_plugin;
	for (i = 0; i < adapter->num_rx_queues; i++)
		Plugin_AddBuffersToRxRing(adapter, i);

	/* Apply the rx filter settins last. */
	vmxnet3_set_mc(adapter->netdev);

	/*
	 * Check link state when first activating device. It will start the
	 * tx queue if the link is up.
	 */
	vmxnet3_check_link(adapter, TRUE);
#ifdef VMXNET3_NAPI
	for(i = 0; i < adapter->num_rx_queues; i++)
		compat_napi_enable(adapter->netdev, &adapter->rx_queue[i].napi);
#endif
	vmxnet3_enable_all_intrs(adapter);
	clear_bit(VMXNET3_STATE_BIT_QUIESCED, &adapter->state);
	return 0;

activate_err:
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_DSAL, 0);
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_DSAH, 0);
	vmxnet3_free_irqs(adapter);
irq_err:
rq_err:
	/* free up buffers we might have allocated */
	vmxnet3_rq_cleanup_all(adapter);
	return err;
}


void
vmxnet3_reset_dev(struct vmxnet3_adapter *adapter)
{
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD, VMXNET3_CMD_RESET_DEV);
}


/*
 * Stop the device. After this function returns, the adapter stop pkt tx/rx
 * and won't generate intrs. The stack won't try to xmit pkts through us,
 * nor will it poll us for pkts. It does the following:
 *
 * 1. ask the vNIC to quiesce
 * 2. disable the vNIC from generating intrs
 * 3. free intr
 * 4. stop the stack from xmiting pkts thru us and polling
 * 5. free rx buffers
 * 6. tx complete pkts pending
 *
 * soft_quiesce indicates to quiesce the software (emulated)
 * device. It doesn't completely stop the vmxnet3 backend. It has to
 * be used when switching to passthrough.
 */

int
vmxnet3_quiesce_dev(struct vmxnet3_adapter *adapter, Bool soft_quiesce)
{
	if (test_and_set_bit(VMXNET3_STATE_BIT_QUIESCED, &adapter->state))
		return 0;

	if (soft_quiesce) {
		uint32 result;

		BUG_ON(adapter->passthru);
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_STOP_EMULATION);
		result = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
		if (result != VMXNET3_NPA_CMD_SUCCESS) {
			printk(KERN_INFO "%s: failed to stop emulation 0x%x\n",
			       adapter->netdev->name, result);
			clear_bit(VMXNET3_STATE_BIT_QUIESCED, &adapter->state);
			return 1;
		}
	} else {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
				       VMXNET3_CMD_QUIESCE_DEV);
	}
	vmxnet3_disable_all_intrs(adapter);
#ifdef VMXNET3_NAPI
	{
		int i;
		for(i = 0; i < adapter->num_rx_queues; i++)
			compat_napi_disable(adapter->netdev,
					    &adapter->rx_queue[i].napi);
	}
#endif
	netif_tx_disable(adapter->netdev);
	adapter->link_speed = 0;
	netif_carrier_off(adapter->netdev);

	vmxnet3_tq_cleanup_all(adapter);
	vmxnet3_rq_cleanup_all(adapter);
	vmxnet3_free_irqs(adapter);
	return 0;
}


static void
vmxnet3_write_mac_addr(struct vmxnet3_adapter *adapter, u8 *mac)
{
	u32 tmp;

	tmp = *(u32 *)mac;
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_MACL, tmp);

	tmp = (mac[5] << 8) | mac[4];
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_MACH, tmp);
}


static int
vmxnet3_set_mac_addr(struct net_device *netdev, void *p)
{
	struct sockaddr *addr = p;
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);

	memcpy(netdev->dev_addr, addr->sa_data, netdev->addr_len);
	vmxnet3_write_mac_addr(adapter, netdev->dev_addr);

	return 0;
}


/* ==================== initialization and cleanup routines ============ */

static int
vmxnet3_alloc_pci_resources(struct vmxnet3_adapter *adapter, Bool *dma64)
{
	int err;
	unsigned long mmio_start, mmio_len;
	struct pci_dev *pdev = adapter->pdev;

	err = pci_enable_device(pdev);
	if (err) {
		printk(KERN_ERR "Failed to enable adapter %s: error %d\n",
		       pci_name(pdev), err);
		return err;
	}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 6)
	if (pci_set_dma_mask(pdev, DMA_BIT_MASK(64)) == 0) {
		if (pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64)) != 0) {
			printk(KERN_ERR
			       "pci_set_consistent_dma_mask failed for adapter %s\n",
			       pci_name(pdev));
			err = -EIO;
			goto err_set_mask;
		}
		*dma64 = TRUE;
	} else {
		if (pci_set_dma_mask(pdev, DMA_BIT_MASK(32)) != 0) {
			printk(KERN_ERR
			       "pci_set_dma_mask failed for adapter %s\n",
			       pci_name(pdev));
			err = -EIO;
			goto err_set_mask;
		}
		*dma64 = FALSE;
	}
#else
	*dma64 = TRUE;
#endif

	err = pci_request_regions(pdev, vmxnet3_driver_name);
	if (err) {
		printk(KERN_ERR
		       "Failed to request region for adapter %s: error %d\n",
		       pci_name(pdev), err);
		goto err_set_mask;
	}

	pci_set_master(pdev);

	mmio_start = pci_resource_start(pdev, 0);
	mmio_len = pci_resource_len(pdev, 0);
	adapter->hw_addr0 = ioremap(mmio_start, mmio_len);
	if (!adapter->hw_addr0) {
		printk(KERN_ERR "Failed to map bar0 for adapter %s\n",
		       pci_name(pdev));
		err = -EIO;
		goto err_ioremap;
	}

	mmio_start = pci_resource_start(pdev, 1);
	mmio_len = pci_resource_len(pdev, 1);
	adapter->hw_addr1 = ioremap(mmio_start, mmio_len);
	if (!adapter->hw_addr1) {
		printk(KERN_ERR "Failed to map bar1 for adapter %s\n",
		       pci_name(pdev));
		err = -EIO;
		goto err_bar1;
	}
	return 0;

err_bar1:
	iounmap(adapter->hw_addr0);
err_ioremap:
	pci_release_regions(pdev);
err_set_mask:
	pci_disable_device(pdev);
	return err;
}


static void
vmxnet3_free_pci_resources(struct vmxnet3_adapter *adapter)
{
	BUG_ON(!adapter->pdev);

	iounmap(adapter->hw_addr0);
	iounmap(adapter->hw_addr1);
	pci_release_regions(adapter->pdev);
	pci_disable_device(adapter->pdev);
}



/*
 * Calculate the # of buffers for a pkt based on mtu, then adjust the size of
 * the 1st rx ring accordingly
 */

static void
vmxnet3_adjust_rx_ring_size(struct vmxnet3_adapter *adapter)
{
	size_t sz, ajusted_ring_size;
	int i;

	if (adapter->netdev->mtu <= SHELL_SMALL_RECV_BUFFER_SIZE) {
		if (!adapter->lro) {
			adapter->skb_buf_size = adapter->netdev->mtu +
				VMXNET3_MAX_ETH_HDR_SIZE;
		} else {
			adapter->skb_buf_size = SHELL_SMALL_RECV_BUFFER_SIZE +
				VMXNET3_MAX_ETH_HDR_SIZE;
		}
		if (adapter->skb_buf_size < VMXNET3_MIN_T0_BUF_SIZE)
			adapter->skb_buf_size = VMXNET3_MIN_T0_BUF_SIZE;

		adapter->rx_buf_per_pkt = 1;
	} else {
		adapter->skb_buf_size = SHELL_SMALL_RECV_BUFFER_SIZE +
			VMXNET3_MAX_ETH_HDR_SIZE;
		sz = adapter->netdev->mtu - adapter->skb_buf_size;
		adapter->rx_buf_per_pkt =
			1 + (sz + SHELL_LARGE_RECV_BUFFER_SIZE - 1) /
			SHELL_LARGE_RECV_BUFFER_SIZE;
	}

	if (adapter->is_shm) {
		adapter->skb_buf_size = PAGE_SIZE;
	}

	/*
	 * for simplicity, force the ring size to be a multiple of
	 * rx_buf_per_pkt * VMXNET3_RING_SIZE_ALIGN
	 */
	sz = adapter->rx_buf_per_pkt * VMXNET3_RING_SIZE_ALIGN;
	ajusted_ring_size = min_t(uint32,
		  (adapter->rx_queue[0].plugin_rq->ringSize + sz -1) / sz * sz,
		  VMXNET3_RX_RING_MAX_SIZE / sz * sz);

	for(i = 0; i < adapter->num_rx_queues; i++)
		adapter->rx_queue[i].plugin_rq->ringSize = ajusted_ring_size;
}

/* Create the specified number of tx queues and rx queues. On failure, it
 * destroys the queues created. */
int
vmxnet3_create_queues(struct vmxnet3_adapter *adapter, u32 tx_ring_size,
		      u32 rx_ring_size)
{
	int err = 0;
	int i;

	for (i = 0; i < adapter->num_tx_queues; i++) {
		adapter->tx_queue[i].adapter = adapter;
		adapter->tx_queue[i].plugin_tq = &adapter->plugin.txQueues[i];
		adapter->tx_queue[i].plugin_tq->ringSize = tx_ring_size;
		adapter->tx_queue[i].data_ring.size = tx_ring_size;
		adapter->tx_queue[i].shared = &adapter->tqd_start[i].ctrl;
		adapter->tx_queue[i].stopped = TRUE;
		adapter->tx_queue[i].qid = i;
		err = vmxnet3_tq_create(&adapter->tx_queue[i], adapter);
		if (err)
			goto queue_err;
	}

	for (i = 0; i < adapter->num_rx_queues; i++) {
		adapter->rx_queue[i].adapter = adapter;
		adapter->rx_queue[i].plugin_rq = &adapter->plugin.rxQueues[i];
	}
	adapter->rx_queue[0].plugin_rq->ringSize = rx_ring_size;
	vmxnet3_adjust_rx_ring_size(adapter);
	for (i = 0; i < adapter->num_rx_queues; i++) {
		adapter->rx_queue[i].shared = &adapter->rqd_start[i].ctrl;
		err = vmxnet3_rq_create(&adapter->rx_queue[i], adapter);
		if (err) {
			if (i == 0) {
				printk(KERN_ERR "Could not allocate any rx"
				       "queues. Aborting.\n");
				goto queue_err;
			} else {
				printk(KERN_INFO "Number of rx queues changed "
				       "to : %d. \n", i);
				adapter->num_rx_queues = i;
				err = 0;
				break;
			}
		}
	}

	return err;

queue_err:
	vmxnet3_tq_destroy_all(adapter);
	return err;
}


/*
 *	Vmxnet3 Shell APIs
 */

static void SHELL_ABI
vmxnet3_shell_log(size_t nargs, const char *str, ...)
{
	va_list va;

	va_start(va, str);
	vprintk(str, va);
	va_end(va);
}


static void SHELL_ABI
vmxnet3_shell_complete_send(struct Shell_TxQueueHandle *handle, uint32 numPkts)
{
	struct vmxnet3_tx_queue *tq = (struct vmxnet3_tx_queue*)handle;
	struct vmxnet3_adapter *adapter = tq->adapter;
	int i;

	/* do in-order completion only */
	for (i = 0; i < numPkts; i++) {
		vmxnet3_unmap_pkt(tq, adapter->pdev, adapter);
		vmxnet3_tx_data_ring_adv_next2comp(&tq->data_ring);
	}

	spin_lock(&tq->tx_lock);
	/*
	 * XXX: PR 531329, we should wake the queue based on plugin
	 * ring and not shadow ring
	 */
	if (unlikely(vmxnet3_tq_stopped(tq, adapter) &&
		     (vmxnet3_tx_shadow_ring_desc_avail(&tq->shadow_ring) >
		      VMXNET3_WAKE_QUEUE_SHADOW_THRESHOLD(tq) &&
		      vmxnet3_tx_data_ring_desc_avail(&tq->data_ring) >
		      VMXNET3_WAKE_QUEUE_DATA_THRESHOLD(tq)) &&
		     netif_carrier_ok(adapter->netdev))) {
		vmxnet3_tq_wake(tq, adapter);
	}
	spin_unlock(&tq->tx_lock);
}


static uint64 SHELL_ABI
vmxnet3_shell_alloc_small_buffer(struct Shell_RxQueueHandle *handle,
				 uint32 ringOffset)
{
	struct vmxnet3_rx_queue *rq = (struct vmxnet3_rx_queue*)handle;
	struct vmxnet3_adapter *adapter = rq->adapter;
	struct vmxnet3_rx_buf_info *rbi = rq->buf_info + ringOffset;

	BUG_ON(ringOffset >= rq->plugin_rq->ringSize *
               PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE);

	if (rbi->buf_type != VMXNET3_RX_BUF_NONE) {
		dev_dbg(&adapter->pdev->dev, "%s: alloc_small_buffer: [%u] %u\n",
			adapter->netdev->name, ringOffset, rbi->buf_type);
		rq->stats.rx_buf_cookie_error++;
		return 0;
	}

	rbi->len = adapter->skb_buf_size;
	rbi->skb = vmxnet3_dev_alloc_skb(adapter, rbi->len +
					 COMPAT_NET_IP_ALIGN);
	if (unlikely(rbi->skb == NULL)) {
		rq->stats.rx_buf_alloc_failure++;
		if (rq->avail_skbs == 0)
			rbi->skb = rq->spare_skb;
		else
			return 0;
	} else if (!adapter->is_shm)
		skb_reserve(rbi->skb, COMPAT_NET_IP_ALIGN);
	rbi->skb->dev = adapter->netdev;
	rbi->dma_addr = vmxnet3_map_single(adapter, rbi->skb, 0, rbi->len,
					   PCI_DMA_FROMDEVICE);
	rbi->buf_type = VMXNET3_RX_BUF_SKB;

	rq->avail_skbs++;
	return rbi->dma_addr;
}


static uint64 SHELL_ABI
vmxnet3_shell_alloc_large_buffer(struct Shell_RxQueueHandle *handle,
				 uint32 ringOffset)
{
	struct vmxnet3_rx_queue *rq = (struct vmxnet3_rx_queue*)handle;
	struct vmxnet3_adapter *adapter = rq->adapter;
	struct vmxnet3_rx_buf_info *rbi = rq->buf_info + ringOffset;

	BUG_ON(ringOffset >= rq->plugin_rq->ringSize *
               PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE);

	if (rbi->buf_type != VMXNET3_RX_BUF_NONE) {
		dev_dbg(&adapter->pdev->dev, "%s: alloc_small_buffer: [%u] %u\n",
			adapter->netdev->name, ringOffset, rbi->buf_type);
		rq->stats.rx_buf_cookie_error++;
		return 0;
	}

	BUILD_BUG_ON(SHELL_LARGE_RECV_BUFFER_SIZE != PAGE_SIZE);
	rbi->len = SHELL_LARGE_RECV_BUFFER_SIZE;
	rbi->page = vmxnet3_alloc_page(adapter);

	if (unlikely(rbi->page == NULL)) {
		rq->stats.rx_buf_alloc_failure++;
		return 0;
	}
	rbi->dma_addr = vmxnet3_map_page(adapter, rbi->page, 0, PAGE_SIZE,
					 PCI_DMA_FROMDEVICE);
	rbi->buf_type = VMXNET3_RX_BUF_PAGE;

	return rbi->dma_addr;
}


static void SHELL_ABI
vmxnet3_shell_free_buffer(struct Shell_RxQueueHandle *handle,
			  uint32 ringOffset)
{
	struct vmxnet3_rx_queue *rq = (struct vmxnet3_rx_queue*)handle;
	struct vmxnet3_adapter *adapter = rq->adapter;
	struct vmxnet3_rx_buf_info *rbi = rq->buf_info + ringOffset;

	BUG_ON(ringOffset >= rq->plugin_rq->ringSize *
               PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE);
	BUG_ON(rbi->buf_type == VMXNET3_RX_BUF_NONE);

	if (rbi->buf_type == VMXNET3_RX_BUF_SKB) {
		pci_unmap_single(adapter->pdev, rbi->dma_addr, rbi->len,
				 PCI_DMA_FROMDEVICE);
		/* starvation skb is release separately */
		if (rbi->skb != rq->spare_skb)
			vmxnet3_dev_kfree_skb(adapter, rbi->skb);
		rq->avail_skbs--;
		rbi->skb = NULL;
	} else if (rbi->buf_type == VMXNET3_RX_BUF_PAGE) {
		pci_unmap_page(adapter->pdev, rbi->dma_addr, rbi->len,
			       PCI_DMA_FROMDEVICE);
		vmxnet3_put_page(adapter, rbi->page);
		rbi->page = NULL;
	}
	rbi->buf_type = VMXNET3_RX_BUF_NONE;
}


static uint32 SHELL_ABI
vmxnet3_shell_indicate_recv(struct Shell_RxQueueHandle *handle,
			    Shell_RecvFrame *frame)
{
	struct vmxnet3_rx_queue *rq = (struct vmxnet3_rx_queue*)handle;
	struct vmxnet3_adapter *adapter = rq->adapter;
	struct vmxnet3_rx_buf_info *rbi;
	struct sk_buff *skb;
	int i;

	rbi = rq->buf_info + frame->sg[0].ringOffset;
	BUG_ON(rbi->buf_type != VMXNET3_RX_BUF_SKB);
	skb = rbi->skb;
	BUG_ON(frame->sgLength == 0);
        BUG_ON(frame->firstSgOffset >= frame->sg[0].length);
	rq->avail_skbs--;
	rbi->skb = NULL;
	pci_unmap_single(adapter->pdev, rbi->dma_addr, rbi->len,
			 PCI_DMA_FROMDEVICE);
	if (rq->spare_skb != skb) {
		skb_reserve(skb, frame->firstSgOffset);
		vmxnet3_skb_put(adapter, skb, frame->sg[0].length);
	}
	rbi->buf_type = VMXNET3_RX_BUF_NONE;

	for (i = 1; i < frame->sgLength; i++) {
		rbi = rq->buf_info + frame->sg[i].ringOffset;
		BUG_ON(rbi->buf_type != VMXNET3_RX_BUF_PAGE);

		pci_unmap_page(rq->adapter->pdev, rbi->dma_addr,
			       rbi->len, PCI_DMA_FROMDEVICE);
		vmxnet3_append_frag(skb, frame->sg + i, rbi);
		rbi->page = NULL;
		rbi->buf_type = VMXNET3_RX_BUF_NONE;
	}

	if (skb == rq->spare_skb) {
		rq->stats.drop_total++;
		vmxnet3_rx_spare_skb_free_frags(adapter, skb);
	} else if (adapter->is_shm) {
		vmxnet3_shm_rx_skb(adapter, skb);

		wake_up(&adapter->shm->rxq);
	} else {
		skb->len += skb->data_len;
		skb->truesize += skb->data_len;

		skb->ip_summed = CHECKSUM_NONE;
		if (adapter->rxcsum && (frame->ipv4 || frame->ipv6)) {
			if (frame->ipXsum != SHELL_XSUM_CORRECT)
				skb->ip_summed = CHECKSUM_NONE;
			else if ((frame->tcp &&
				  frame->tcpXsum != SHELL_XSUM_CORRECT) ||
				 (frame->udp &&
				  frame->udpXsum != SHELL_XSUM_CORRECT))
				skb->ip_summed = CHECKSUM_NONE;
			else
				skb->ip_summed = VM_CHECKSUM_UNNECESSARY;
		}

		skb->protocol = eth_type_trans(skb, adapter->netdev);
#ifdef VMXNET3_NAPI
		if (unlikely(adapter->vlan_grp && frame->vlan)) {
			vlan_hwaccel_receive_skb(skb, adapter->vlan_grp,
						 frame->vlanTag);
		} else {
			netif_receive_skb(skb);
		}
#else
		if (unlikely(adapter->vlan_grp && frame->vlan)) {
			vlan_hwaccel_rx(skb, adapter->vlan_grp, frame->vlanTag);
		} else {
			netif_rx(skb);
		}
#endif
	}
	rq->rxd_done++;
	adapter->netdev->last_rx = jiffies;

	return 0;
}


/*
 * setup rings, allocate necessary resources, request for IRQs, configure
 * the device. The device is functional after this function finishes
 * successfully.
 * Returns 0 on success, negative errno value on failure
 */

static int
vmxnet3_open(struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter;
	Plugin_State *plugin;
	int err, i;

	adapter = compat_netdev_priv(netdev);
	plugin = &adapter->plugin;

	plugin->size = sizeof(*plugin);
	plugin->majorVersion = 1;
	plugin->minorVersion = 0;
	plugin->offsetToPrivateSpace = offsetof(Plugin_State, privateSpace);

	plugin->shellApi.allocSmallBuffer = vmxnet3_shell_alloc_small_buffer;
	plugin->shellApi.allocLargeBuffer = vmxnet3_shell_alloc_large_buffer;
	plugin->shellApi.freeBuffer = vmxnet3_shell_free_buffer;
	plugin->shellApi.completeSend = vmxnet3_shell_complete_send;
	plugin->shellApi.indicateRecv = vmxnet3_shell_indicate_recv;
	plugin->shellApi.log = vmxnet3_shell_log;

	plugin->mtu = adapter->netdev->mtu;
	
	plugin->numTxQueues = adapter->num_tx_queues;
	for (i = 0; i < adapter->num_tx_queues; i++) {
		plugin->txQueues[i].handle =
			(struct Shell_TxQueueHandle*)&adapter->tx_queue[i];
		spin_lock_init(&adapter->tx_queue[i].tx_lock);
	}

	plugin->numRxQueues = adapter->num_rx_queues;
	for (i = 0; i < adapter->num_rx_queues; i++)
		plugin->rxQueues[i].handle =
			(struct Shell_RxQueueHandle*)&adapter->rx_queue[i];

	if (adapter->lro) {
		plugin->features = PLUGIN_FEATURES_LRO;
	}

	if (adapter->is_shm) {
		printk(KERN_INFO "bringing up shared memory vmxnet3 %s\n",
		       netdev->name);
		err = vmxnet3_shm_open(adapter, netdev->name, shm_pool_size);
		if (err) {
			goto shm_err;
		}
	}
	err = vmxnet3_create_queues(adapter, VMXNET3_DEF_TX_RING_SIZE,
				    VMXNET3_DEF_RX_RING_SIZE);
	if (err)
		goto queue_err;

	dev_dbg(&adapter->pdev->dev, "rxQueues[0] %p %"FMT64"u %u %u\n",
		plugin->rxQueues[0].ringBaseVA,
		plugin->rxQueues[0].ringBasePA,
		plugin->rxQueues[0].ringLength,
		plugin->rxQueues[0].ringSize);
	dev_dbg(&adapter->pdev->dev, "txQueues[0] %p %"FMT64"u %u %u\n",
		plugin->txQueues[0].ringBaseVA,
		plugin->txQueues[0].ringBasePA,
		plugin->txQueues[0].ringLength,
		plugin->txQueues[0].ringSize);

	err = vmxnet3_activate_dev(adapter, FALSE);
	if (err)
		goto activate_err;

	COMPAT_NETDEV_MOD_INC_USE_COUNT;

	return 0;

activate_err:
	vmxnet3_rq_destroy_all(adapter);
	vmxnet3_tq_destroy_all(adapter);
queue_err:
	if (adapter->is_shm) {
		vmxnet3_shm_close(adapter);
	}
shm_err:
	return err;
}


static int
vmxnet3_close(struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);

	/*
	 * Reset_work may be in the middle of resetting the device, wait for its
	 * completion.
	 */
	while (test_and_set_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state))
		compat_msleep(1);

	vmxnet3_quiesce_dev(adapter, FALSE);

	if (adapter->is_shm) {
		vmxnet3_shm_close(adapter);
	}

	vmxnet3_rq_destroy_all(adapter);
	vmxnet3_tq_destroy_all(adapter);

	COMPAT_NETDEV_MOD_DEC_USE_COUNT;

	clear_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state);


	return 0;
}


/*
 * Called to forcibly close the device when the driver failed to re-activate it.
 */
void
vmxnet3_force_close(struct vmxnet3_adapter *adapter)
{
	/*
	 * we must clear VMXNET3_STATE_BIT_RESETTING, otherwise
	 * vmxnet3_close() will deadlock.
	 */
	BUG_ON(test_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state));

#ifdef VMXNET3_NAPI
	{
		int i;
		for (i = 0; i < adapter->num_rx_queues; i++)
			compat_napi_enable(adapter->netdev,
					   &adapter->rx_queue[i].napi);
	}
#endif
	dev_close(adapter->netdev);
}


static int
vmxnet3_change_mtu(struct net_device *netdev, int new_mtu)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	int err = 0;

	if (new_mtu < VMXNET3_MIN_MTU || new_mtu > VMXNET3_MAX_MTU)
		return -EINVAL;

	if (new_mtu > 1500 && !adapter->jumbo_frame)
		return -EINVAL;

	netdev->mtu = new_mtu;

	/*
	 * Reset_work may be in the middle of resetting the device, wait for its
	 * completion.
	 */
	while (test_and_set_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state))
		compat_msleep(1);

	if (netif_running(netdev)) {
		vmxnet3_quiesce_dev(adapter, FALSE);
		vmxnet3_reset_dev(adapter);

		/* we need to re-create the rx queue based on the new mtu */
		vmxnet3_rq_destroy_all(adapter);
		vmxnet3_adjust_rx_ring_size(adapter);
		err = vmxnet3_rq_create_all(adapter);
		if (err) {
			printk(KERN_ERR "%s: failed to re-create rx queues,"
				" error %d. Closing it.\n", netdev->name, err);
			goto out;
		}

		err = vmxnet3_activate_dev(adapter, FALSE);
		if (err) {
			printk(KERN_ERR "%s: failed to re-activate, error %d. "
				"Closing it\n", netdev->name, err);
			goto out;
		}
	}

out:
	clear_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state);
	if (err)
		vmxnet3_force_close(adapter);

	return err;
}


static void
vmxnet3_declare_features(struct vmxnet3_adapter *adapter, Bool dma64)
{
	struct net_device *netdev = adapter->netdev;

	netdev->features = NETIF_F_SG |
		NETIF_F_HW_CSUM |
		NETIF_F_HW_VLAN_TX |
		NETIF_F_HW_VLAN_RX |
		NETIF_F_HW_VLAN_FILTER |
		NETIF_F_TSO;
	printk(KERN_INFO "features: sg csum vlan jf tso");

	adapter->rxcsum = TRUE;
	adapter->jumbo_frame = TRUE;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)
	 /* LRO feature control by module param */
	if (!disable_lro) {
#else
	 /* LRO feature control by ethtool */
		netdev->features |= NETIF_F_LRO;
#endif

		adapter->lro = TRUE;
		printk(" lro");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)
	}
#endif

#ifdef NETIF_F_TSO6
	netdev->features |= NETIF_F_TSO6;
	printk(" tsoIPv6");
#endif

	if (dma64) {
		netdev->features |= NETIF_F_HIGHDMA;
		printk(" highDMA");
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)
	netdev->vlan_features = netdev->features;
#endif
	printk("\n");
}


static void
vmxnet3_read_mac_addr(struct vmxnet3_adapter *adapter, u8 *mac)
{
	u32 tmp;

	tmp = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_MACL);
	*(u32 *)mac = tmp;

	tmp = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_MACH);
	mac[4] = tmp & 0xff;
	mac[5] = (tmp >> 8) & 0xff;
}


/*
 * Looks at the number of irqs available and rearranges the irq to queue
 * mappings in a suitable way.
 */
static void
vmxnet3_adjust_intr_map(struct vmxnet3_adapter *adapter, int intr_avail)
{
	u32 mask;
	struct vmxnet3_intr_ctx *ctx;
	if (intr_avail > 3 && intr_avail < (adapter->num_rx_queues + 1))
		intr_avail = 3;
	else
		intr_avail = 1;
	adapter->intr.num_intrs = intr_avail;

	switch(intr_avail) {
	case 1:
		/* Assign all queues to single intr vector */
		ctx = &adapter->intr.ctx[0];
		mask = (1 << (adapter->num_tx_queues + 1)) - 1;
		ctx->tx_map = mask;
		mask = (1 << (adapter->num_rx_queues + 1)) - 1;
		ctx->rx_map = mask;
		ctx->other = TRUE;
		break;
	case 3:
		/* Assign an irq to each - tx queues, rx queue and event each */
		ctx = &adapter->intr.ctx[0];
		mask = (1 << (adapter->num_tx_queues + 1)) - 1;
		ctx->tx_map = mask;
		ctx = &adapter->intr.ctx[1];
		mask = (1 << (adapter->num_rx_queues + 1)) - 1;
		ctx->rx_map = mask;
		ctx->other = TRUE;
		break;
	}
}

/* Looks at the number of tx and rx queues and produces bit map for each
 * irq dictating which queues it should process. Returns the total number
 * of irqs required.
 */
static int
vmxnet3_produce_intr_map(struct vmxnet3_adapter *adapter, int share)
{
	int i, vector = 0;
	u32 mask = 0;

	if (share == 1) {
		for (i = 0; i < 3; i++) {
			adapter->intr.ctx[i].adapter = adapter;
			adapter->intr.ctx[i].index = i;
#ifdef CONFIG_PCI_MSI
			adapter->intr.msix_entries[i].entry = i;
#endif
		}
		mask = (1 << (adapter->num_tx_queues + 1)) - 1;
		adapter->intr.ctx[0].tx_map = mask;
		mask = (1 << (adapter->num_rx_queues + 1)) - 1;
		adapter->intr.ctx[1].rx_map = mask;
		adapter->intr.ctx[2].other = TRUE;
		return 3;
	}

	/* Use one irq among all tx and rx queues */
	if (share == 2) {
		for (i = 0; i < 2; i++) {
			adapter->intr.ctx[i].adapter = adapter;
			adapter->intr.ctx[i].index = i;
#ifdef CONFIG_PCI_MSI
			adapter->intr.msix_entries[i].entry = i;
#endif
		}
		mask = (1 << (adapter->num_tx_queues + 1)) - 1;
		adapter->intr.ctx[0].tx_map = mask;
		mask = (1 << (adapter->num_rx_queues + 1)) - 1;
		adapter->intr.ctx[0].rx_map = mask;
		adapter->intr.ctx[1].other = TRUE;
		return 2;
	}

	/* Each tx/rx queue gets one irq. */
	for (i = 0; i < adapter->num_rx_queues; i++) {
#ifdef CONFIG_PCI_MSI
		adapter->intr.msix_entries[vector].entry = vector;
#endif
		adapter->intr.ctx[vector].adapter = adapter;
		adapter->intr.ctx[vector].index = vector;
		adapter->intr.ctx[vector++].rx_map |= (1 << i);
	}

	for (i = 0; i < adapter->num_tx_queues; i++) {
#ifdef CONFIG_PCI_MSI
		adapter->intr.msix_entries[vector].entry = vector;
#endif
		adapter->intr.ctx[vector].adapter = adapter;
		adapter->intr.ctx[vector].index = vector;
		adapter->intr.ctx[vector++].tx_map |= (1 << i);
	}

	adapter->intr.ctx[vector].index = vector;
	adapter->intr.ctx[vector].adapter = adapter;
#ifdef CONFIG_PCI_MSI
	adapter->intr.msix_entries[vector].entry = vector;
#endif
	adapter->intr.ctx[vector++].other = TRUE;
	return vector;
}



#ifdef CONFIG_PCI_MSI
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19)

/*
 * Enable MSIx vectors. Returns 0 on successful and other values for error.
 */

static int
vmxnet3_acquire_msix_vectors(struct vmxnet3_adapter *adapter,
                             int vectors)
{
	int err = 0, vector_threshold;
	vector_threshold = min(vectors, VMXNET3_LINUX_MIN_MSIX_VECT);

	while (vectors >= vector_threshold) {
		err = pci_enable_msix(adapter->pdev, adapter->intr.msix_entries,
				vectors);
		if (!err) {
			adapter->intr.num_intrs = vectors;
			return 0;
		} else if (err < 0) {
			printk(KERN_ERR "Failed to enable MSI-X for %s, error"
			       " %d\n",	adapter->netdev->name, err);
			vectors = 0;
		} else {
			/* If fails to enable required number of MSI-x vectors
			 * try enabling 3 of them. One each for rx, tx and event
			 */
			vectors = vector_threshold;
			printk(KERN_ERR "Failed to enable %d MSI-X for %s, try"
			       " %d instead\n", vectors, adapter->netdev->name,
			       vector_threshold);
		}
	}

   printk(KERN_INFO "Number of MSI-X interrupts which can be allocated are "
	  "lower than min threshold required.\n");
   return err;
}


#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19) */
#endif /* CONFIG_PCI_MSI */

/*
 * read the intr configuration, pick the intr type, and enable MSI/MSI-X if
 * needed. adapter->intr.{type, mask_mode, num_intr} are modified
 */

static void
vmxnet3_alloc_intr_resources(struct vmxnet3_adapter *adapter)
{
	u32 cfg;

	/* intr settings */
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_GET_CONF_INTR);
	cfg = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
	adapter->intr.type = cfg & 0x3;
	adapter->intr.mask_mode = (cfg >> 2) & 0x3;
	adapter->intr.num_intrs = vmxnet3_produce_intr_map(adapter,
					(share_irq[adapter->dev_number]));

#ifdef CONFIG_PCI_MSI
	if (adapter->intr.type == VMXNET3_IT_AUTO) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19)
		/* start with MSI-X */
		adapter->intr.type = VMXNET3_IT_MSIX;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 13)
		adapter->intr.type = VMXNET3_IT_MSI;
#else
		adapter->intr.type = VMXNET3_IT_INTX;
#endif
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19)
	if (adapter->intr.type == VMXNET3_IT_MSIX) {
		int err;

		err = vmxnet3_acquire_msix_vectors(adapter,
						   adapter->intr.num_intrs);
		if (!err) {
			return;
		} else if (err >= VMXNET3_LINUX_MIN_MSIX_VECT) {
			vmxnet3_adjust_intr_map(adapter, err);
			return;
		}
		adapter->intr.type = VMXNET3_IT_MSI;
	}
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 13)
	if (adapter->intr.type == VMXNET3_IT_MSI) {
		adapter->num_rx_queues = 1;
		vmxnet3_adjust_intr_map(adapter, 1);
		if (!pci_enable_msi(adapter->pdev))
			return;
	}
#endif
#endif /* CONFIG_PCI_MSI*/

	/* INT-X related setting */
	adapter->num_rx_queues = 1;
	adapter->intr.type = VMXNET3_IT_INTX;
	vmxnet3_adjust_intr_map(adapter, 1);
}


static void
vmxnet3_free_intr_resources(struct vmxnet3_adapter *adapter)
{
#ifdef CONFIG_PCI_MSI
	if (adapter->intr.type == VMXNET3_IT_MSIX)
		pci_disable_msix(adapter->pdev);
	else if (adapter->intr.type == VMXNET3_IT_MSI)
		pci_disable_msi(adapter->pdev);
	else
#endif
	{
		BUG_ON(adapter->intr.type != VMXNET3_IT_INTX);
	}

}


/*
 * Called when the stack detects a Tx hang. Schedule a job to reset the device
 */

static void
vmxnet3_tx_timeout(struct net_device *netdev)
{
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	adapter->tx_timeout_count++;

	printk(KERN_ERR "%s: tx hang\n", adapter->netdev->name);
	compat_schedule_work(&adapter->reset_work);
	netif_wake_queue(adapter->netdev);
}


static void
vmxnet3_reset_work(compat_work_arg data)
{
	struct vmxnet3_adapter *adapter;

	adapter = COMPAT_WORK_GET_DATA(data, struct vmxnet3_adapter,
				       reset_work);

	/*
         * If another thread is resetting the device, wait for it to complete
         * as we don't know if it's a reset_work() or a passthru_work().
         */
	while (test_and_set_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state))
		compat_msleep(1);

	/* if the device is closed or is being opened, we must leave it alone */
	if (netif_running(adapter->netdev) &&
	    (adapter->netdev->flags & IFF_UP)) {
		printk(KERN_INFO "%s: resetting\n", adapter->netdev->name);

		vmxnet3_quiesce_dev(adapter, FALSE);
		vmxnet3_reset_dev(adapter);
		vmxnet3_activate_dev(adapter, FALSE);
	} else {
		printk(KERN_INFO "%s: already closed\n", adapter->netdev->name);
	}

	clear_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state);
}


static void
vmxnet3_passthru_work(compat_work_arg data)
{
	struct vmxnet3_adapter *adapter;
        u32 ret;

	adapter = COMPAT_WORK_GET_DATA(data, struct vmxnet3_adapter,
				       passthru_work);

	/* if another thread is resetting the device, wait for it to complete */
	while (test_and_set_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state))
		compat_msleep(1);
        
	/*
         * Make sure we need to switch to passthru.
         * There are two things to check:
         *
         * - are we already in passthru? if yes, then we can't make
         *   the transition. It can happen in the following case:
         *   We have received and interrupt to switch out followed
         *   by another switch-in interrupt. passthru_work() may have
         *   been scheduled before reset_work(). In this case, let's
         *   ignore the passthru request and the reset_work() will
         *   happen after. At the end of the reset, the backend may
         *   initiate a new passthru request if needed.
         *
         * - is the backend in passthru? if no, then it means the
         *   switch has been cancelled.
         */
	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD, VMXNET3_CMD_GET_DID_LO);
	ret = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_CMD);
	if (adapter->passthru || ret != VMXNET3_DID_PASSTHRU) {
		printk(KERN_INFO "%s: cannot perform switch\n",
		       adapter->netdev->name);
		goto done;
	}

	/* if the device is closed, we must leave it alone */
	if (netif_running(adapter->netdev)) {
		if (vmxnet3_quiesce_dev(adapter, TRUE) == 0) {
			if (vmxnet3_activate_dev(adapter, TRUE) == 0) {
				printk(KERN_ERR "%s: passthru mode\n",
				       adapter->netdev->name);
			} else {
				printk(KERN_INFO "%s: activate dev failed\n",
				       adapter->netdev->name);
				/*
				 * We already have quiesced the
				 * adapter in the guest; tell the
				 * device BE to do a hard quiesce
				 */
				VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD, 
						       VMXNET3_CMD_QUIESCE_DEV);
				vmxnet3_reset_dev(adapter);
				vmxnet3_activate_dev(adapter, FALSE);
				printk(KERN_ERR "%s: emulation mode\n",
				      adapter->netdev->name);
			}
		} else {
			printk(KERN_INFO "%s: soft quiesce failed\n",
			       adapter->netdev->name);
			vmxnet3_quiesce_dev(adapter, FALSE);
			vmxnet3_reset_dev(adapter);
			vmxnet3_activate_dev(adapter, FALSE);
			printk(KERN_ERR "%s: emulation mode\n",
			       adapter->netdev->name);
		}
	} else {
		printk(KERN_INFO "%s: already closed\n", adapter->netdev->name);
	}

 done:
	clear_bit(VMXNET3_STATE_BIT_RESETTING, &adapter->state);
}


/*
 * Initialize a vmxnet3 device. Returns 0 on success, negative errno code
 * otherwise. Initialize the h/w and allocate necessary resources
 */

static int
vmxnet3_probe_device(struct pci_dev *pdev,
		     const struct pci_device_id *id)
{
#ifdef HAVE_NET_DEVICE_OPS
	static const struct net_device_ops vmxnet3_netdev_ops = {
		.ndo_open = vmxnet3_open,
		.ndo_stop = vmxnet3_close,
		.ndo_start_xmit = vmxnet3_xmit_frame,
		.ndo_set_mac_address = vmxnet3_set_mac_addr,
		.ndo_change_mtu = vmxnet3_change_mtu,
		.ndo_get_stats = vmxnet3_get_stats,
		.ndo_tx_timeout = vmxnet3_tx_timeout,
		.ndo_set_multicast_list = vmxnet3_set_mc,
		.ndo_vlan_rx_register = vmxnet3_vlan_rx_register,
		.ndo_vlan_rx_add_vid = vmxnet3_vlan_rx_add_vid,
		.ndo_vlan_rx_kill_vid = vmxnet3_vlan_rx_kill_vid,
#ifdef CONFIG_NET_POLL_CONTROLLER
		.ndo_poll_controller = vmxnet3_netpoll,
#endif
	};
#endif	/* HAVE_NET_DEVICE_OPS  */
	int err;
	Bool dma64 = FALSE; /* stupid gcc */
	u32 ver;
	struct net_device *netdev;
	struct vmxnet3_adapter *adapter;
	u8 mac[ETH_ALEN];
	int size;
	int num_tx_queues = num_tqs[atomic_read(&devices_found)];
	int num_rx_queues = num_rqs[atomic_read(&devices_found)];

	/* CONFIG_NETDEVICES_MULTIQUEUE dictates if skb has queue_mapping field.
	 * It was introduced in 2.6.23 onwards but Ubuntu 804 (2.6.24) and
	 * SLES 11(2.6.25) do not have it.
	 */

#ifdef VMXNET3_RSS
	if (num_rx_queues <= 0)
		num_rx_queues = min(VMXNET3_DEVICE_MAX_RX_QUEUES,
				    (int)num_online_cpus());
	else
		num_rx_queues = min(VMXNET3_DEVICE_MAX_RX_QUEUES,
				    num_rx_queues);
#else
	num_rx_queues = 1;
#endif


#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 25) || defined(CONFIG_NETDEVICES_MULTIQUEUE)
	if (num_tx_queues <= 0)
		num_tx_queues = min(VMXNET3_DEVICE_MAX_TX_QUEUES,
				    (int)num_online_cpus());
	else
		num_tx_queues = min(VMXNET3_DEVICE_MAX_TX_QUEUES,
				    num_tx_queues);
	netdev = alloc_etherdev_mq(sizeof(struct vmxnet3_adapter),
				   num_tx_queues);
#else
	num_tx_queues = 1;
	netdev = compat_alloc_etherdev(sizeof(struct vmxnet3_adapter));
#endif
	printk(KERN_INFO "# of Tx queues : %d, # of Rx queues : %d\n",
	       num_tx_queues, num_rx_queues);

	if (!netdev) {
		printk(KERN_ERR "Failed to alloc ethernet device %s\n",
			pci_name(pdev));
		return -ENOMEM;
	}

	pci_set_drvdata(pdev, netdev);
	adapter = compat_netdev_priv(netdev);
	adapter->netdev = netdev;
	adapter->pdev = pdev;

	adapter->shared = pci_alloc_consistent(adapter->pdev,
			  sizeof(struct Vmxnet3_DriverShared),
			  &adapter->shared_pa);
	if (!adapter->shared) {
		printk(KERN_ERR "Failed to allocate memory for %s\n",
			pci_name(pdev));
		err = -ENOMEM;
		goto err_alloc_shared;
	}

	adapter->num_rx_queues = num_rx_queues;
	adapter->num_tx_queues = num_tx_queues;

	size = sizeof(struct Vmxnet3_TxQueueDesc) * adapter->num_tx_queues;
	size += sizeof(struct Vmxnet3_RxQueueDesc) * adapter->num_rx_queues;

	adapter->tqd_start = pci_alloc_consistent(adapter->pdev, size,
						  &adapter->queue_desc_pa);

	if (!adapter->tqd_start) {
		printk(KERN_ERR "Failed to allocate memory for %s\n",
			pci_name(pdev));
		err = -ENOMEM;
		goto err_alloc_queue_desc;
	}
	adapter->rqd_start = (struct Vmxnet3_RxQueueDesc *)(adapter->tqd_start
						      + adapter->num_tx_queues);

	adapter->pm_conf = kmalloc(sizeof(struct Vmxnet3_PMConf), GFP_KERNEL);
	if (adapter->pm_conf == NULL) {
		printk(KERN_ERR "Failed to allocate memory for %s\n",
			pci_name(pdev));
		err = -ENOMEM;
		goto err_alloc_pm;
	}

	adapter->plugin_conf = kmalloc(sizeof(NPA_PluginConf), GFP_KERNEL);
	if (adapter->plugin_conf == NULL) {
		printk(KERN_ERR "Failed to allocate memory for %s\n",
		       pci_name(pdev));
		err = -ENOMEM;
		goto err_alloc_plugin_conf;
	}

	adapter->plugin_memio =
		pci_alloc_consistent(adapter->pdev,
				     (NPA_MEMIO_NUMPAGES + 1) * PAGE_SIZE,
				     &adapter->plugin_memio_pa);
	if (!adapter->plugin_memio) {
		err = -ENOMEM;
		goto err_alloc_plugin_mmio;
	}

	adapter->plugin_shared =
		pci_alloc_consistent(adapter->pdev,
				     (NPA_SHARED_NUMPAGES + 1) * PAGE_SIZE,
				     &adapter->plugin_shared_pa);
	if (!adapter->plugin_shared) {
		err = -ENOMEM;
		goto err_alloc_plugin_shared;
	}

	err = vmxnet3_alloc_pci_resources(adapter, &dma64);
	if (err < 0)
		goto err_alloc_pci;

	ver = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_VRRS);
	if (ver & 1) {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_VRRS, 1);
	} else {
		printk(KERN_ERR
		       "Incompatible h/w version (0x%x) for adapter %s\n",
		       ver, pci_name(pdev));
		err = -EBUSY;
		goto err_ver;
	}

	ver = VMXNET3_READ_BAR1_REG(adapter, VMXNET3_REG_UVRS);
	if (ver & 1) {
		VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_UVRS, 1);
	} else {
		printk(KERN_ERR
		       "Incompatible upt version (0x%x) for adapter %s\n",
		       ver, pci_name(pdev));
		err = -EBUSY;
		goto err_ver;
	}

	vmxnet3_declare_features(adapter, dma64);

	adapter->dev_number = atomic_read(&devices_found);
	adapter->is_shm = FALSE;
	if (adapter->dev_number < VMXNET3_SHM_MAX_DEVICES) {
		if (enable_shm[adapter->dev_number] == 1) {
			if (!correct_shm_disclaimer) {
				printk(KERN_ERR
				       "Did not activate shm, disclaimer missing\n");
			} else {
				adapter->is_shm = TRUE;
			}
		}
	}

	vmxnet3_alloc_intr_resources(adapter);

	vmxnet3_read_mac_addr(adapter, mac);
	memcpy(netdev->dev_addr,  mac, netdev->addr_len);

#ifdef HAVE_NET_DEVICE_OPS
	netdev->netdev_ops = &vmxnet3_netdev_ops;
#else
	netdev->open  = vmxnet3_open;
	netdev->stop  = vmxnet3_close;
	netdev->hard_start_xmit = vmxnet3_xmit_frame;
	netdev->set_mac_address = vmxnet3_set_mac_addr;
	netdev->change_mtu = vmxnet3_change_mtu;
	netdev->get_stats = vmxnet3_get_stats;
	netdev->tx_timeout = vmxnet3_tx_timeout;
	netdev->set_multicast_list = vmxnet3_set_mc;
	netdev->vlan_rx_register = vmxnet3_vlan_rx_register;
	netdev->vlan_rx_add_vid  = vmxnet3_vlan_rx_add_vid;
	netdev->vlan_rx_kill_vid = vmxnet3_vlan_rx_kill_vid;
#ifdef CONFIG_NET_POLL_CONTROLLER
	netdev->poll_controller  = vmxnet3_netpoll;
#endif
#endif /* HAVE_NET_DEVICE_OPS  */
	netdev->watchdog_timeo = 5 * HZ;
	vmxnet3_set_ethtool_ops(netdev);

	COMPAT_INIT_WORK(&adapter->reset_work, vmxnet3_reset_work, adapter);
	COMPAT_INIT_WORK(&adapter->passthru_work, vmxnet3_passthru_work,
			 adapter);

#ifdef VMXNET3_NAPI
	if (adapter->intr.type == VMXNET3_IT_MSIX) {
                int i;
                for (i = 0; i < adapter->num_rx_queues; i++) {
                        compat_netif_napi_add(netdev,
                                              &adapter->rx_queue[i].napi,
                                              vmxnet3_poll_rx_only, 64);
                }
        } else {
                compat_netif_napi_add(netdev, &adapter->rx_queue[0].napi,
                                      vmxnet3_poll, 64);
        }
#endif

	COMPAT_SET_MODULE_OWNER(netdev);
	COMPAT_SET_NETDEV_DEV(netdev, &pdev->dev);

	err = register_netdev(netdev);
	if (err) {
		printk(KERN_ERR "Failed to register adapter %s\n",
		       pci_name(pdev));
		goto err_register;
	}

	set_bit(VMXNET3_STATE_BIT_QUIESCED, &adapter->state);
	vmxnet3_check_link(adapter, FALSE);
	atomic_inc(&devices_found);
	return 0;

err_register:
	vmxnet3_free_intr_resources(adapter);
err_ver:
	vmxnet3_free_pci_resources(adapter);
err_alloc_pci:
	pci_free_consistent(adapter->pdev,
			    (NPA_SHARED_NUMPAGES + 1) * PAGE_SIZE,
			    adapter->plugin_shared, adapter->plugin_shared_pa);
err_alloc_plugin_shared:
	pci_free_consistent(adapter->pdev, 
			    (NPA_MEMIO_NUMPAGES + 1) * PAGE_SIZE,
			    adapter->plugin_memio, adapter->plugin_memio_pa);
err_alloc_plugin_mmio:
	kfree(adapter->plugin_conf);
err_alloc_plugin_conf:
	kfree(adapter->pm_conf);
err_alloc_pm:
	pci_free_consistent(adapter->pdev, size, adapter->tqd_start,
			    adapter->queue_desc_pa);
err_alloc_queue_desc:
	pci_free_consistent(adapter->pdev, sizeof(struct Vmxnet3_DriverShared),
			    adapter->shared, adapter->shared_pa);
err_alloc_shared:
	pci_set_drvdata(pdev, NULL);
	compat_free_netdev(netdev);
	return err;
}


static void
vmxnet3_remove_device(struct pci_dev *pdev)
{
	struct net_device *netdev = pci_get_drvdata(pdev);
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	int num_rx_queues = -1;
	int size = 0;
#ifdef VMXNET3_RSS
        if (num_rx_queues <= 0)
                num_rx_queues = min(VMXNET3_DEVICE_MAX_RX_QUEUES,
                                    (int)num_online_cpus());
        else
                num_rx_queues = min(VMXNET3_DEVICE_MAX_RX_QUEUES,
                                    num_rx_queues);
#else
        num_rx_queues = 1;
#endif


	flush_scheduled_work();

	unregister_netdev(netdev);

	vmxnet3_free_intr_resources(adapter);
	vmxnet3_free_pci_resources(adapter);
	pci_free_consistent(adapter->pdev,
			    (NPA_SHARED_NUMPAGES + 1) * PAGE_SIZE,
			    adapter->plugin_shared, adapter->plugin_shared_pa);
	pci_free_consistent(adapter->pdev, 
			    (NPA_MEMIO_NUMPAGES + 1) * PAGE_SIZE,
			    adapter->plugin_memio, adapter->plugin_memio_pa);
	kfree(adapter->plugin_conf);
	kfree(adapter->pm_conf);

	size = sizeof(struct Vmxnet3_TxQueueDesc) * adapter->num_tx_queues;
        size += sizeof(struct Vmxnet3_RxQueueDesc) * num_rx_queues;
	pci_free_consistent(adapter->pdev, size, adapter->tqd_start,
			    adapter->queue_desc_pa);
	pci_free_consistent(adapter->pdev, sizeof(struct Vmxnet3_DriverShared),
			    adapter->shared, adapter->shared_pa);
	compat_free_netdev(netdev);
}


#ifdef CONFIG_PM

/*
 *      May programs the wake-up filters if configured to do so.
 */

static int
vmxnet3_suspend(struct pci_dev *pdev, pm_message_t state)
{
	struct net_device *netdev = pci_get_drvdata(pdev);
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	struct Vmxnet3_PMConf *pmConf;
	struct ethhdr *ehdr;
	struct arphdr *ahdr;
	u8 *arpreq;
	struct in_device *in_dev;
	struct in_ifaddr *ifa;
	int i = 0;

	if (!netif_running(netdev))
		return 0;

	vmxnet3_disable_all_intrs(adapter);
	vmxnet3_free_irqs(adapter);
	vmxnet3_free_intr_resources(adapter);
	netif_device_detach(netdev);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
	netif_stop_queue(netdev);
#else
	netif_tx_stop_all_queues(netdev);
#endif

	/* Create wake-up filters. */
	pmConf = adapter->pm_conf;
	memset(pmConf, 0, sizeof(*pmConf));

	if (adapter->wol & WAKE_UCAST) {
		pmConf->filters[i].patternSize = ETH_ALEN;
		pmConf->filters[i].maskSize = 1;
		memcpy(pmConf->filters[i].pattern, netdev->dev_addr, ETH_ALEN);
		pmConf->filters[i].mask[0] = 0x3F; /* LSB ETH_ALEN bits */

		set_flag_le16(&pmConf->wakeUpEvents, VMXNET3_PM_WAKEUP_FILTER);
		i++;
	}

	if (adapter->wol & WAKE_ARP) {
		in_dev = in_dev_get(netdev);
		if (!in_dev)
			goto skip_arp;

		ifa = (struct in_ifaddr *)in_dev->ifa_list;
		if (!ifa) {
			dev_dbg(&adapter->pdev->dev, "Cannot program WoL ARP"
				" filter for %s: no IPv4 address.\n",
				netdev->name);
			in_dev_put(in_dev);
			goto skip_arp;
		}
		pmConf->filters[i].patternSize = ETH_HLEN + /* Ethernet header */
			sizeof(struct arphdr) +                  /* ARP header */
			2 * ETH_ALEN +                           /* 2 Ethernet addresses */
			2 * sizeof (u32);                     /* 2 IPv4 addresses */
		pmConf->filters[i].maskSize =
			(pmConf->filters[i].patternSize - 1) / 8 + 1;
		/* ETH_P_ARP in Ethernet header. */
		ehdr = (struct ethhdr *)pmConf->filters[i].pattern;
		ehdr->h_proto = htons(ETH_P_ARP);
		/* ARPOP_REQUEST in ARP header. */
		ahdr = (struct arphdr *)&pmConf->filters[i].pattern[ETH_HLEN];
		ahdr->ar_op = htons(ARPOP_REQUEST);
		arpreq = (u8 *)(ahdr + 1);

		/* The Unicast IPv4 address in 'tip' field. */
		arpreq += 2 * ETH_ALEN + sizeof(u32);
		*(u32 *)arpreq = ifa->ifa_address;

		/* The mask for the relevant bits. */
		pmConf->filters[i].mask[0] = 0x00;
		pmConf->filters[i].mask[1] = 0x30; /* ETH_P_ARP */
		pmConf->filters[i].mask[2] = 0x30; /* ARPOP_REQUEST */
		pmConf->filters[i].mask[3] = 0x00;
		pmConf->filters[i].mask[4] = 0xC0; /* IPv4 TIP */
		pmConf->filters[i].mask[5] = 0x03; /* IPv4 TIP */
		in_dev_put(in_dev);

		set_flag_le16(&pmConf->wakeUpEvents, VMXNET3_PM_WAKEUP_FILTER);
		i++;
	}

skip_arp:
	if (adapter->wol & WAKE_MAGIC)
		set_flag_le16(&pmConf->wakeUpEvents, VMXNET3_PM_WAKEUP_MAGIC);

	pmConf->numFilters = i;

	adapter->shared->devRead.pmConfDesc.confVer = cpu_to_le32(1);
	adapter->shared->devRead.pmConfDesc.confLen = cpu_to_le32(sizeof(
								  *pmConf));
	adapter->shared->devRead.pmConfDesc.confPA = cpu_to_le64(virt_to_phys(
								 pmConf));

	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_UPDATE_PMCFG);

	compat_pci_save_state(pdev);
	pci_enable_wake(pdev, compat_pci_choose_state(pdev, state),
			adapter->wol);
	pci_disable_device(pdev);
	pci_set_power_state(pdev, compat_pci_choose_state(pdev, state));

	return 0;
}


static int
vmxnet3_resume(struct pci_dev *pdev)
{
	int err;
	struct net_device *netdev = pci_get_drvdata(pdev);
	struct vmxnet3_adapter *adapter = compat_netdev_priv(netdev);
	struct Vmxnet3_PMConf *pmConf;

	if (!netif_running(netdev))
		return 0;

	/* Destroy wake-up filters. */
	pmConf = adapter->pm_conf;
	memset(pmConf, 0, sizeof(*pmConf));

	adapter->shared->devRead.pmConfDesc.confVer = cpu_to_le32(1);
	adapter->shared->devRead.pmConfDesc.confLen = cpu_to_le32(sizeof(
								  *pmConf));
	adapter->shared->devRead.pmConfDesc.confPA = cpu_to_le32(virt_to_phys(
								 pmConf));

	netif_device_attach(netdev);
	pci_set_power_state(pdev, PCI_D0);
	compat_pci_restore_state(pdev);
	err = pci_enable_device(pdev);
	if (err != 0)
		return err;

	pci_enable_wake(pdev, PCI_D0, 0);

	VMXNET3_WRITE_BAR1_REG(adapter, VMXNET3_REG_CMD,
			       VMXNET3_CMD_UPDATE_PMCFG);
	vmxnet3_alloc_intr_resources(adapter);
	vmxnet3_request_irqs(adapter);
	vmxnet3_enable_all_intrs(adapter);

	return 0;
}

#endif

static struct pci_driver vmxnet3_driver = {
	.name		= vmxnet3_driver_name,
	.id_table	= vmxnet3_pciid_table,
	.probe		= vmxnet3_probe_device,
	.remove		= vmxnet3_remove_device,
#ifdef CONFIG_PM
	.suspend	= vmxnet3_suspend,
	.resume		= vmxnet3_resume,
#endif
};


static int __init
vmxnet3_init_module(void)
{
	printk(KERN_INFO "%s - version %s\n", VMXNET3_DRIVER_DESC,
	       VMXNET3_DRIVER_VERSION_REPORT);

	correct_shm_disclaimer = shm_disclaimer &&
		(strncmp(shm_disclaimer, VMXNET3_SHM_DISCLAIMER,
		strlen(VMXNET3_SHM_DISCLAIMER)) == 0);

#ifdef CONFIG_COMPAT
#ifndef HAVE_UNLOCKED_IOCTL
	if (correct_shm_disclaimer) {
		register_ioctl32_conversion(SHM_IOCTL_TX, NULL);
		register_ioctl32_conversion(SHM_IOCTL_ALLOC_ONE, NULL);
		register_ioctl32_conversion(SHM_IOCTL_FREE_ONE, NULL);
	}
#endif
#endif
	return pci_register_driver(&vmxnet3_driver);
}

module_init(vmxnet3_init_module);

static void
vmxnet3_exit_module(void)
{
#ifdef CONFIG_COMPAT
#ifndef HAVE_UNLOCKED_IOCTL
	if (correct_shm_disclaimer) {
		unregister_ioctl32_conversion(SHM_IOCTL_TX);
		unregister_ioctl32_conversion(SHM_IOCTL_ALLOC_ONE);
		unregister_ioctl32_conversion(SHM_IOCTL_FREE_ONE);
	}
#endif
#endif
	pci_unregister_driver(&vmxnet3_driver);
}


module_exit(vmxnet3_exit_module);

MODULE_AUTHOR("VMware, Inc.");
MODULE_DESCRIPTION(VMXNET3_DRIVER_DESC);
MODULE_LICENSE("GPL v2");
MODULE_VERSION(VMXNET3_DRIVER_VERSION_STRING);
/*
 * Starting with SLE10sp2, Novell requires that IHVs sign a support agreement
 * with them and mark their kernel modules as externally supported via a
 * change to the module header. If this isn't done, the module will not load
 * by default (i.e., neither mkinitrd nor modprobe will accept it).
 */
MODULE_INFO(supported, "external");
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)
module_param(disable_lro, int, 0);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 2)
MODULE_PARM(enable_shm, "0-10i");
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 10)
module_param_array(enable_shm, int, num_enable_shm, 0);
#else
module_param_array(enable_shm, int, &num_enable_shm, 0);
#endif
MODULE_PARM_DESC(enable_shm, "Shared memory enable");
module_param(shm_disclaimer, charp, 0);
MODULE_PARM_DESC(shm_disclaimer, "Shared memory disclaimer");
module_param(shm_pool_size, int, 0);
MODULE_PARM_DESC(shm_pool_size, "Shared memory pool size");

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 25) || \
    defined(CONFIG_NETDEVICES_MULTIQUEUE)
static unsigned int nparams = 0;
module_param_array(num_rqs, int, &nparams, 0);
MODULE_PARM_DESC(num_rqs, "Number of receive queues in each adapter. Comma "
		 " separated list of ints. Default is 0 which makes number"
		 " of queues same as number of CPUs");
module_param_array(num_tqs, int, &nparams, 0);
MODULE_PARM_DESC(num_tqs, "Number of transmit queues in each adapter. Comma "
		 "separated list of ints. Default is 0 which makes number"
		 " of queues same as number of CPUs");
module_param_array(share_irq, int, &nparams, 0);
MODULE_PARM_DESC(share_irq, "Share an irq among all tx & rx queues. "
		 "Comma separated list of 1s and 0s - one for each NIC. "
		 "1 to share, 0 to not, default is 1");
#endif

