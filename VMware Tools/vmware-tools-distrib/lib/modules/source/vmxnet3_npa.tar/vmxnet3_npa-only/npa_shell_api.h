/*********************************************************
 * Copyright (C) 2009-2010 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/

#ifndef _SHELL_API_H
#define _SHELL_API_H

#include "vm_basic_types.h"

#define SHELL_SMALL_RECV_BUFFER_SIZE         2048
#define SHELL_LARGE_RECV_BUFFER_SIZE         4096

/*
 * Plugin should never indicate more than 4 sg's in a rx packet.
 */
#define SHELL_MAX_RECV_SG_LEN                4

/*
 * Over allocate the sg array for future use
 */
#define SHELL_MAX_LRO_RECV_SG_LEN            18

#define SHELL_RECV_HASH_FUNCTION_NONE        0
#define SHELL_RECV_HASH_FUNCTION_TOEPLITZ    1

#define SHELL_RECV_HASH_TYPE_NONE            0
#define SHELL_RECV_HASH_TYPE_IPV4            1
#define SHELL_RECV_HASH_TYPE_TCPIPV4         5 /* 1 | 4 */
#define SHELL_RECV_HASH_TYPE_IPV6            2
#define SHELL_RECV_HASH_TYPE_TCPIPV6         6 /* 2 | 4 */

#define SHELL_XSUM_UNKNOWN                   0
#define SHELL_XSUM_CORRECT                   1
#define SHELL_XSUM_INCORRECT                 2

struct Shell_RxQueueHandle;
struct Shell_TxQueueHandle;

typedef
#include "vmware_pack_begin.h"
struct Shell_RecvFrameSG {
   uint32   ringOffset;
   uint32   length;
}
#include "vmware_pack_end.h"
Shell_RecvFrameSG;

typedef
#include "vmware_pack_begin.h"
struct Shell_RecvFrame {
   uint32   sgLength;
   uint32   byteLength;
   uint32   firstSgOffset;    // offset of data in the first sg, used to skip
                              // headers the hardware might have DMA'ed
   uint32   _pad;
   Shell_RecvFrameSG sg[SHELL_MAX_LRO_RECV_SG_LEN];
   Bool     perfectFiltered;  // indicate if packet exactly matches RX filters
   Bool     vlan;
   uint16   vlanTag;          // valid if vlan == TRUE
   uint32   rssHashFunction;
   uint32   rssHashType;      // valid if rssHashFunction != 0
   uint32   rssHashValue;     // valid if rssHashFunction and rssHashType != 0
   Bool     ipv4;
   Bool     ipv6;
   Bool     nonIp;
   Bool     tcp;
   Bool     udp;
   uint8    ipXsum;           // UNKNOWN , CORRECT , INCORRECT
   uint8    tcpXsum;          // UNKNOWN , CORRECT , INCORRECT
   uint8    udpXsum;          // UNKNOWN , CORRECT , INCORRECT
}
#include "vmware_pack_end.h"
Shell_RecvFrame;

#if defined(__i386__)
#ifdef _MSC_VER
/*
 * Windows is usually stdcall while Linux is cdecl, so let's force it
 * to be cdecl for both and we will make sure Windows shell functions
 * are declared cdecl.
 */
#define SHELL_ABI __cdecl
#else /* non MSC compiler (gcc) */
/*
 * Linux is usually cdecl, however it may be compiled with -mregparm=3.
 * Let's overwrite it to pass all arguments on the stack.
 */
#define SHELL_ABI __attribute__((regparm(0)))
#endif
#elif defined(__x86_64__)
/*
 * Nothing special for x64. Windows makes shell functions pointing to
 * stub functions doing parameters translation explicitely.
 */
#define SHELL_ABI
#else
#error "Cannot detect bitness"
#endif

/*
 *----------------------------------------------------------------------------
 *
 * Shell_AllocSmallBuffer --
 *
 *    Allocate a 'small' buffer from the shell identified by the ringOffset.
 *    ringOffset can range from [0..#descs-for-all-rings] and is used
 *    by the shell to identify the buffer in the shadow ring maintained by
 *    shell.
 *
 *    This call can only be made from Plugin_AddBuffersToRxRing
 *
 * Result:
 *    PA of the buffer
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint64 (SHELL_ABI Shell_AllocSmallBuffer)(struct Shell_RxQueueHandle *handle,
                                                  uint32 ringOffset);

/*
 *----------------------------------------------------------------------------
 *
 * Shell_AllocLargeBuffer --
 *
 *    Allocate a 'large' buffer from the shell identified by the ringOffset.
 *    ringOffset can range from [0..#descs-for-all-rings] and is used
 *    by the shell to identify the buffer in the shadow ring maintained by
 *    shell.
 *
 *    This call can only be made from Plugin_AddBuffersToRxRing
 *
 * Result:
 *    PA of the buffer
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint64 (SHELL_ABI Shell_AllocLargeBuffer)(struct Shell_RxQueueHandle *handle,
                                                  uint32 ringOffset);

/*
 *----------------------------------------------------------------------------
 *
 * Shell_FreeBuffer --
 *
 *    Free the buffer allocated from Shell_Alloc{Small|Large}Buffer identified
 *    by the cookie 'ringOffset'
 *
 *    This call can be made from Plugin_CheckRxRing(Plugin_AddBuffersToRxRing?)
 *
 * Result:
 *    None.
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef void (SHELL_ABI Shell_FreeBuffer)(struct Shell_RxQueueHandle *handle,
                                          uint32 ringOffset);



/*
 *----------------------------------------------------------------------------
 *
 * Shell_CompleteSend --
 *
 *    Indicate # of pre-tso tx completion to the shell.
 *
 *    This call can only be made from Plugin_CheckTxRing
 *
 * Result:
 *    None.
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef void (SHELL_ABI Shell_CompleteSend)(struct Shell_TxQueueHandle *handle,
                                            uint32 numPkts);


/*
 *----------------------------------------------------------------------------
 *
 * Shell_IndicateRecv --
 *
 *    Indicate a receive frame to the shell. The buffer ownership is transferred
 *    to the shell and the rest of offload information is transferred along with
 *    in the RecvFrame
 *
 *    This call can only be made from Plugin_CheckRxRing
 *
 * Result:
 *    0 for success, 1 for failure
 *
 * Side-effects:
 *    The buffers are passed up to the OS stack.
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (SHELL_ABI Shell_IndicateRecv)(struct Shell_RxQueueHandle *handle,
                                              Shell_RecvFrame *frame);

/*
 *----------------------------------------------------------------------------
 *
 * Shell_Log --
 *
 *    Simple logging function.
 *
 *    This call can only be made from anyplace (except NPA_PluginMain)
 *
 * Result:
 *    None.
 *
 * Side-effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

typedef void (SHELL_ABI Shell_Log)(size_t nargs, const char *fmt, ...);

typedef
#include "vmware_pack_begin.h"
struct Shell_Api {
   Shell_AllocSmallBuffer  *allocSmallBuffer;
   Shell_AllocLargeBuffer  *allocLargeBuffer;
   Shell_FreeBuffer        *freeBuffer;
   Shell_CompleteSend      *completeSend;
   Shell_IndicateRecv      *indicateRecv;
   Shell_Log               *log;
}
#include "vmware_pack_end.h"
Shell_Api;

#endif // _SHELL_API_H
